
module.exports = {
    "/alfresco": {
        "target": "https://d1s-sidec-ged1.armf.local",
        "secure": false,
        "changeOrigin": true
    }
};
