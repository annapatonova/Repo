/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */

import { Routes } from '@angular/router';
import { AuthGuardEcm } from '@alfresco/adf-core';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AppLayoutComponent } from './components/app-layout/app-layout.component';
import { CreateDossierComponent } from './components/dossier/create-dossier/create-dossier.component';
import { AddressBookComponent } from './components/address-book/address-book.component';
import { DossierListComponent } from './components/dossier/dossier-list/dossier-list.component';
import { EntityComponent } from './components/address-book/entity/entity.component';
import { ContactComponent } from './components/address-book/contact/contact.component';
import { DemandeComponent } from './components/demande/demande.component';
import { DossierComponent } from './components/dossier/dossier.component';

export const appRoutes: Routes = [
  /* TODO TMP todelete  { path: 'files/:nodeId/view', component: FileViewComponent, canActivate: [AuthGuardEcm], outlet: 'overlay' },
   */
  {
    path: '',
    component: AppLayoutComponent,
    canActivate: [AuthGuardEcm],
    children: [
      {
        path: '',
        component: DossierListComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'home',
        component: HomeComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'dossiers',
        component: DossierListComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'dossier/:dossierRef/:tabIndx',
        component: DossierComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'create-dossier',
        component: CreateDossierComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'address-book',
        component: AddressBookComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'entity',
        component: EntityComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'contact',
        component: ContactComponent,
        canActivate: [AuthGuardEcm]
      },
      {
        path: 'demande/:demandeRef',
        component: DemandeComponent,
        canActivate: [AuthGuardEcm]
      }
    ],
    canActivateChild: [AuthGuardEcm]
  },
  {
    path: 'login',
    component: LoginComponent
  }
];
