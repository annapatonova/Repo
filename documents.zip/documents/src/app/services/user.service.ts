/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Injectable } from '@angular/core';
import { AuthenticationService } from '@alfresco/adf-core';
import { Observable } from 'rxjs';
import { CommonsService } from './commons.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  WS_PERM = '/alfresco/s/sidec/securite/globalPermissions';

  constructor(
    private readonly commonsService: CommonsService,
    private readonly authService: AuthenticationService
    ) {}

   getCurrentUsername(): string{
      return this.authService.getEcmUsername();
   }

   getUserPermission(): Observable<any> {
      return this.commonsService.get(this.WS_PERM);
    }
   
}
