/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { AlfrescoApiService, AppConfigService, AppConfigValues, OauthConfigModel } from '@alfresco/adf-core';

import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonsService {

  ecmHost: string;

  constructor(
    private readonly http: HttpClient,
    private readonly apiService: AlfrescoApiService,
    private readonly appConfig: AppConfigService
  ) {
    this.ecmHost = this.appConfig.get<string>('ecmHost');
  }

  verifyConnection() {
    const oauth: OauthConfigModel = Object.assign({}, this.appConfig.get<OauthConfigModel>(AppConfigValues.OAUTHCONFIG, null));
    if (oauth) {
      oauth.redirectUri = window.location.origin + (oauth.redirectUri || '/');
      oauth.redirectUriLogout = window.location.origin + (oauth.redirectUriLogout || '/');
    }
  }

  request(method: ('get' | 'getBlob' |'post' | 'postProgress'), path: string, headers?: HttpHeaders, params?: HttpParams, fd?: any): Observable<any>{

    this.verifyConnection();

    if(!params){
      params = new HttpParams();
    }

    const ticket = this.apiService.getInstance().getTicketEcm();

    params = params.append('alf_ticket', ticket);

    switch (method) {
      case 'get':
        return this.http.get(this.ecmHost + path, {'headers': headers, 'params': params});
        case 'getBlob':
          return this.http.get(this.ecmHost + path, {'headers': headers, 'params': params, observe: 'response', responseType: 'blob' as 'json'});
      case 'post':
        return this.http.post(this.ecmHost + path, fd, {'headers': headers,  'params': params });
      case 'postProgress':
          return this.http.post(this.ecmHost + path, fd, { 'headers': headers, 'params': params, reportProgress: true, observe: 'events'});
      default:
        return of(null);
    }
    
  }

  post(path: string, fd: any, params?: HttpParams, headers?: HttpHeaders): Observable<any> {
    return this.request('post', path, headers, params, fd);
  }

  postProgress(path: string, fd: FormData){
    return this.request('postProgress', path, null, null, fd);
  }

  get(path: string, params?: HttpParams, headers?: HttpHeaders): Observable<any> {
    return this.request('get', path, headers, params);
  }

  getBlob(path: string, params?: HttpParams, headers?: HttpHeaders){
    return this.request('getBlob', path, headers, params);
  }
}
