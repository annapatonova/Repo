/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DemandeResponse } from 'app/model/demande';

import { Observable } from 'rxjs';

import { CommonsService } from './commons.service';

@Injectable({
  providedIn: 'root'
})
export class DemandeService {

  WS_SUPPORT_LIST = '/alfresco/s/sidec/demande/listeSupports';
  WS_TYPE_LIST = '/alfresco/s/sidec/demande/listeThemes';

  WS_DEMANDE = '/alfresco/s/sidec/demande/detailsDemande';
  WS_DEMANDE_LIST = '/alfresco/s/sidec/demande/demandesDossier';
  WS_DEMANDE_CREATE = '/alfresco/s/sidec/demande/create';
  WS_DEMANDE_UPDATE = '/alfresco/s/sidec/demande/majProprietesDemande';

  WS_DEMANDE_SEND = '/alfresco/s/sidec/demande/envoyerDemandes';

  WS_DEMANDE_RESPONSE_COMMENT = '/alfresco/s/sidec/demande/reponse/commentaire';


  constructor(
    private readonly commonsService: CommonsService
  ) { }


  saveComment(response: DemandeResponse, comment: string) {

    const body = {
      "sidec:identifiantReponseDemande": response.id,
      "id": response.nodeId,
      "sidec:refDemandeReponse": response.refDemande,
      "sidec:commentaireReponseDemande": comment

    }

    return this.commonsService.post(this.WS_DEMANDE_RESPONSE_COMMENT, body);

  }

  getDemande(refDemande: string): Observable<any> {

    let params = new HttpParams();

    params = params.append('refDemande', refDemande);

    return this.commonsService.get(this.WS_DEMANDE, params);
  }

  getSupportList(keyword?: string): Observable<any> {
    return this.getDemandeInfo(this.WS_SUPPORT_LIST, keyword);
  }

  getTypeList(keyword?: string): Observable<any> {
    return this.getDemandeInfo(this.WS_TYPE_LIST, keyword);
  }

  getDemandeInfo(path: string, keyword?: string): Observable<any> {

    let params = new HttpParams();

    if (keyword) {
      params = params.append('keyword', keyword.toString());
    }

    return this.commonsService.get(path, params);
  }

  getDemandeList(refDossier: string, pageSize?: number, pageNumber?: number): Observable<any> {

    let params = new HttpParams();

    params = params.append('refDossier', refDossier);

    if (pageSize && pageNumber) {

      params = params.append('pageSize', pageSize.toString());

      params = params.append('pageNumber', pageNumber.toString());

    }

    return this.commonsService.get(this.WS_DEMANDE_LIST, params);
  }

  buildDemandeProps(data: any) {

    const meta = {
      'cm:name': data.demandeLabel.trim(),
      'sidec:refDemande': data.demandeNumber,
      'sidec:refDossierParent': data.dossierRef,
      'sidec:entiteDemande': data.demandeEntity && data.demandeEntity !== '' ? data.demandeEntity.nom : '',
      'sidec:contactsDemande': data.demandeContacts.map(contact => contact.courriel),
      'sidec:supportDemande': data.support === null ? '' : data.support,
      'sidec:themesDemande': data.demandeType,
      'sidec:descriptionDemande': data.demandeDescription,
      'sidec:listeDocsAttendus': data.demandeExpectedDocuments,
      'sidec:demandesLiees': (data.anotherDemandes && data.anotherDemandes !== null) ? data.anotherDemandes : []
    };

    if (data.automaticRestartDelay !== null) {
      meta['sidec:delaiRelanceAuto'] = data.automaticRestartDelay;
    } else {
      meta['sidec:delaiRelanceAuto'] = 0;
    }

    if (data.expectedResponseDate !== null) {
      meta['sidec:dateReponseAttendue'] = data.expectedResponseDate;
    }

    return JSON.stringify(meta);
  }

  createDemande(data: any, files: File[]): Observable<any> {

    const fd = new FormData();

    for (const file of files) {
      fd.append('sidec_piecesJointesDemande', file);
    }

    fd.append('sidec_metadata', this.buildDemandeProps(data));

    return this.commonsService.post(this.WS_DEMANDE_CREATE, fd);
  }

  updateDemande(data: any): Observable<any> {

    const fd = new FormData();

    fd.append('sidec_metadata', this.buildDemandeProps(data));

    return this.commonsService.post(this.WS_DEMANDE_UPDATE, fd);
  }

  sendDemandes(refDemandeList: string[]) {

    const refList = [];
    refDemandeList.forEach(refDemande => {
      refList.push({ 'refDemande': refDemande })
    });

    const body = {
      'demandes_sidec': refList
    }

    return this.commonsService.post(this.WS_DEMANDE_SEND, body);

  }
}
