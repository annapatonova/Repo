/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Injectable } from '@angular/core';
import { HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable} from 'rxjs';

import { CommonsService } from './commons.service';

/*  tmp pour voir après la connexion   this.apiService.getInstance().webScript.executeWebScript('GET', this.scriptPath, this.scriptArgs, this.contextRoot, this.servicePath)
 */

@Injectable({
  providedIn: 'root'
})
export class DossierService {

  WS_CREATE = '/alfresco/s/sidec/dossier/create';
  WS_UPDATE = '/alfresco/s/sidec/dossier/majPproprietesDossier';
  WS_LIST_DOSSIERS_EN_COURS = '/alfresco/s/sidec/dossier/listeDossiersEnCours';
  WS_PROPERIES = '/alfresco/s/sidec/dossier/detailsDossier';
  WS_INV_BASE = '/alfresco/s/sidec/dossier/baseInventaire';


  constructor(
    private readonly commonsService: CommonsService
  ) {}

  
  buildDossierProps(data: any){
    return {
      'sidec:refDossier': data.dossierRef.trim(),
      'cm:name': data.dossierName.trim(),
      'sidec:dateOuvertureDossier': data.dossierOpenDate,
      'sidec:entiteDossier': data.entity,
      'sidec:contactDossier': data.contact,
      'sidec:chefDeMission': data.missionHead.login,
      'sidec:autresChargesDeDossier': data.otherDossierCharged.map(user=> user.login)
    };
  }

  createDossier(data: any, files: File[]): Observable<any> {

    const fd = new FormData();

    for (const file of files) {
      fd.append('sidec_piecesJointesDossier', file);
    }

    fd.append('sidec_metadata', JSON.stringify(this.buildDossierProps(data)));

    return this.commonsService.post(this.WS_CREATE, fd);
  }

  updateDossier(data: any): Observable<any> {

    const fd = new FormData();

    fd.append('sidec_metadata', JSON.stringify(this.buildDossierProps(data)));

    return this.commonsService.post(this.WS_UPDATE, fd);
  }

  getDossierEnCoursList(pageSize?: number, pageNumber?: number): Observable<any> {

    let params = new HttpParams();

    if (pageSize && pageNumber) {

      params = params.append('pageSize', pageSize.toString());

      params = params.append('pageNumber', pageNumber.toString());

    }

    return this.commonsService.get(this.WS_LIST_DOSSIERS_EN_COURS, params);
  }

  getDossierProperies(refDossier: string): Observable<any> {

    let params = new HttpParams();

    params = params.append('refDossier', refDossier);

    return this.commonsService.get(this.WS_PROPERIES, params);
  }

  getInventoryBase(refDossier: string): Observable<any> {
    let params = new HttpParams();

    params = params.append('refDossier', refDossier);

    let headers = new HttpHeaders({ 
      'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
      'Accept': 'application/.xlsx' 
   });

    return this.commonsService.getBlob(this.WS_INV_BASE, params, headers);
  }
}
