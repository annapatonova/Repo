/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable, Subject } from 'rxjs';

import { CommonsService } from './commons.service';

@Injectable({
  providedIn: 'root'
})
export class AddressBookService {

  /* Entity Services */
  WS_ENTITY = '/alfresco/s/sidec/annuaire/detailsEntite';
  WS_ENTITIES = '/alfresco/s/sidec/annuaire/listeEntites';
  WS_ENTITIES_A = '/alfresco/s/sidec/annuaire/listeEntitesActives';
  WS_ENTITY_CREATE = '/alfresco/s/sidec/annuaire/createEntite';
  WS_ENTITY_UPDATE = '/alfresco/s/sidec/annuaire/majEntite';

  /* Contact Services */
  WS_CONTACT = '/alfresco/s/sidec/annuaire/detailsContact';
  WS_CONTACTS = '/alfresco/s/sidec/annuaire/listeContacts';
  WS_CONTACTS_A = '/alfresco/s/sidec/annuaire/listeContactsActifs';
  WS_CONTACT_CREATE = '/alfresco/s/sidec/annuaire/createContact';
  WS_CONTACT_UPDATE = '/alfresco/s/sidec/annuaire/majContact';

  WS_CIVILITIES = '/alfresco/s/sidec/annuaire/listeCivilites';

  WS_COUNTRIES = '/alfresco/s/sidec/annuaire/listePays';

  WS_USERS = '/alfresco/s/sidec/annuaire/listeUtilisateursMetiers';

  constructor(
    private readonly commonsService: CommonsService,
  ) {}

  getContact(email: string): Observable<any> {

    let params = new HttpParams();

    params = params.append('idContact', email);

    return this.commonsService.get(this.WS_CONTACT, params);
  }

  getEntity(name: string): Observable<any> {

    let params = new HttpParams();

    params = params.append('nomEntite', name);

    return this.commonsService.get(this.WS_ENTITY, params);
  }

  getUsers(creationDossier: string, pageSize?: number, pageNumber?: number, keyword?: string): Observable<any> {

    let params = new HttpParams();

    if (pageSize && pageNumber) {
      params = params.append('pageSize', pageSize.toString());
      params = params.append('pageNumber', pageNumber.toString());
    }

    if (keyword) {
      params = params.append('keyword', keyword);
    }

    params = params.append('creationDossier', creationDossier);

    return this.commonsService.get(this.WS_USERS, params);
  }

  getCivilities(pageSize?: number, pageNumber?: number, keyword?: string): Observable<any> {
    return this.getAdressBookWS(this.WS_CIVILITIES, pageSize, pageNumber, keyword);
  }

  getContactsActives(direction?:string, pageSize?: number, pageNumber?: number, keyword?: string): Observable<any> {
    return this.getAdressBookWS(this.WS_CONTACTS_A, pageSize, pageNumber, keyword, null, direction);
  }

  getContacts(pageSize?: number, pageNumber?: number, keyword?: string, statut?: 'Actif' | 'Inactif'): Observable<any> {
    return this.getAdressBookWS(this.WS_CONTACTS, pageSize, pageNumber, keyword, statut);
  }

  getEtitiesActives(direction?:string, pageSize?: number, pageNumber?: number, keyword?: string): Observable<any> {
    return this.getAdressBookWS(this.WS_ENTITIES_A, pageSize, pageNumber, keyword, null, direction);
  }

  getEtities(pageSize?: number, pageNumber?: number, keyword?: string, statut?: 'Actif' | 'Inactif'): Observable<any> {
    return this.getAdressBookWS(this.WS_ENTITIES, pageSize, pageNumber, keyword, statut);
  }

  getCountriesList(pageSize?: number, pageNumber?: number, keyword?: string): Observable<any> {
    return this.getAdressBookWS(this.WS_COUNTRIES, pageSize, pageNumber, keyword);
  }

  getAdressBookWS(pathName: string, pageSize?: number, pageNumber?: number, keyword?: string, statut?: string, direction?: string): Observable<any> {

    let params = new HttpParams();

    if (pageSize && pageNumber) {
      params = params.append('pageSize', pageSize.toString());
      params = params.append('pageNumber', pageNumber.toString());
    }

    if (statut) {
      params = params.append('statut', statut);
    }

    if (direction) {
      params = params.append('direction', direction);
    }

    if (keyword) {
      params = params.append('keyword', keyword);
    }

    return this.commonsService.get(pathName, params);
  }

  //TODO a revoire
  isExistentCountry(country: string): Observable<boolean> {
    
    const subject = new Subject<boolean>();

    this.getAdressBookWS(this.WS_COUNTRIES, null, null, country).subscribe(
      rep => {
        const countries: string[] = rep.data.pays.map(p => p.libelleFR);
        if (countries.indexOf(country) > -1) {
          subject.next(true);
        } else {
          subject.next(false);
        }
      }
    );
    return subject.asObservable();
  }

  buildEntityProps(data: any) {

    const meta = {
      'nom': data.name,
      'statut': data.statut,
      'commentaire': data.comment,
      'adresse_postale': data.address,
      'code_postal': data.zipCode,
      'ville': data.city,
      'pays': data.country,
      'telephone': data.phone
    };

    if (data.contacts) {
      meta['contacts'] = data.contacts;
    }

    return meta;
  }

  createEntity(data: any): Observable<any> {

    const fd = new FormData();

    fd.append('sidec_metadata', JSON.stringify(this.buildEntityProps(data)));

    return this.commonsService.post(this.WS_ENTITY_CREATE, fd);

  }

  updateEntity(data: any): Observable<any> {

    const fd = new FormData();

    fd.append('sidec_metadata', JSON.stringify(this.buildEntityProps(data)));

    return this.commonsService.post(this.WS_ENTITY_UPDATE, fd);

  }

  buildContactProps(data: any) {
    return {
      civilite: data.civility,
      nom: data.lastName,
      prenom: data.firstName,
      courriel: data.email,
      statut: data.statut,
      fonction: data.function,
      adresse_postale: data.address,
      code_postal: data.zipCode,
      ville: data.city,
      pays: data.country,
      telephone: data.phone,
      telecopie: data.fax,
      entites: data.entities
    };
  }

  createContact(data: any): Observable<any> {

    const fd = new FormData();

    fd.append('sidec_metadata', JSON.stringify(this.buildContactProps(data)));

    return this.commonsService.post(this.WS_CONTACT_CREATE, fd);

  }

  updateContact(data: any): Observable<any> {

    const fd = new FormData();

    fd.append('sidec_metadata', JSON.stringify(this.buildContactProps(data)));

    return this.commonsService.post(this.WS_CONTACT_UPDATE, fd);
  }

}
