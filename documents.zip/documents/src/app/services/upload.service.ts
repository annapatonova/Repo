/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { HttpEventType } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { CommonsService } from './commons.service';
import { UploadFile, UploadFileStatus } from 'app/model/commons';


@Injectable({
  providedIn: 'root'
})
export class UploadService {

  WS_DOSSIER_DOCUMENTS_UPLOAD = '/alfresco/s/sidec/dossier/ajouterPJ';

  isUploading = false;

  files: UploadFile[] = [];

  done = new BehaviorSubject(false);
 
  constructor(
    private readonly commonsService: CommonsService
  ) {}

  isDone(){
    return this.done.asObservable();
  }


  addToQueueAndUpload(uploadFiles: UploadFile[]){
    uploadFiles.forEach(file => {
      this.addToQueue(file);
    });

    this.uploadNext();
  }

  addToQueue(uploadFile: UploadFile){

    uploadFile.upload = () => this.upload(uploadFile);
    uploadFile.remove = () => this.removeFromQueue(uploadFile);
    uploadFile.cancel = () => this.cancel(uploadFile);

    this.files.push(uploadFile);

  }

  private removeFromQueue(file: UploadFile) {

    const index = this.files.indexOf(file);
    if(index !== -1){
      this.files = this.files.slice(index);
    }
    
  }

  cancel(file: UploadFile){
    file.request.unsubscribe();
    file.progress = 0;
    file.status = UploadFileStatus.Pending;
  }

  uploadNext(){

    if(this.files.length > 0 && !this.isUploading){
      this.files.pop().upload();
    }

    if(this.files.length === 0){
      this.done.next(true);
    }
  }

 private upload(uploadFile: UploadFile){

    this.isUploading = true;

    uploadFile.request = this.uploadFile(uploadFile.file, uploadFile.parentRef, uploadFile.parentType).pipe(
      map((event: any) => {
        if (event.type === HttpEventType.UploadProgress) {
          uploadFile.status = UploadFileStatus.Progress;
          uploadFile.progress = Math.round((100 / event.total) * event.loaded);
        } else if (event.type === HttpEventType.Response) {
          if(event.body?.statut === 'OK'){
            uploadFile.status = UploadFileStatus.Success;
          }else{
            uploadFile.status = UploadFileStatus.Error;
            uploadFile.errorMessage = event.body?.message;
          }
          return true;
        }
        return false;
      }),
      catchError((err: any) => {
        uploadFile.status = UploadFileStatus.Error;
        uploadFile.errorMessage = `Erreur technique : ${err}`;
        return of(true);
      })
    ).subscribe(
      rep => {
        if(rep){
          this.isUploading = false;
          this.uploadNext();
        }
      }
    );
    }

  uploadFile(file: File, parentRef: string, parentType: 'dossier' | 'demande'): Observable<any> {

    let meta;
    const fd = new FormData();

    switch (parentType) {
      case 'dossier':
        meta = { 'sidec:refDossier': parentRef.trim() };
        fd.append('sidec_piecesJointesDossier', file);
        break;
      case 'demande':
        meta = { 'sidec:refDemande': parentRef.trim() };
        break;
      default:
        break;
    }

    fd.append('sidec_metadata', JSON.stringify(meta));

    return this.commonsService.postProgress(this.WS_DOSSIER_DOCUMENTS_UPLOAD, fd);
  }
}
