/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ControlContainer, FormGroup, Validators } from '@angular/forms';

import { merge } from 'rxjs';

import { ContactInt, EntityInt } from 'app/model/adress-book';
import { DossierPermissionsInt } from 'app/model/dossier';
import { User } from 'app/model/users';
import { AddressBookService } from 'app/services/address-book.service';
import { ListValidator } from 'app/validators/list-validator';
import { RegexValidator } from 'app/validators/regex-validator';


interface ResponseData {
  contacts?: ContactInt[];
  entites?: EntityInt[];
  users?: User[];
}

@Component({
  selector: 'app-dossier-form',
  templateUrl: './dossier-form.component.html',
  styleUrls: ['./dossier-form.component.css']
})
export class DossierFormComponent implements OnInit {

  @Input() form: FormGroup;

  @Input()
  mode: 'edit' | 'create' = 'create';

  @Input()
  permissions: DossierPermissionsInt;

  @Input()
  direction: 'DEN' | 'DC';

  @Input()
  canModifyStatut = false;

  @Output()
  isReady = new EventEmitter<void>();

  @Output()
  isServerError = new EventEmitter<void>();

  entitis: string[];

  contacts: string[];

  users: User[];

  constructor(
    private readonly adressBookService: AddressBookService,
    public readonly controlContainer: ControlContainer
  ) { }

  statutList = ['Ouvert (Analyse)', 'Transmis au SCCS/DICS', 'Clos', 'Archivé'];

  ngOnInit(): void {

    this.initValidators();

    merge(
      this.adressBookService.getContactsActives(this.direction),
      this.adressBookService.getEtitiesActives(this.direction),
      this.adressBookService.getUsers('t')
    ).subscribe(
      rep => { 
        this.onSuccess(rep); 
      },
      err => { 
        this.handleError(); 
      }
    );
  }

  onSuccess(rep: any) {

    if (rep.statut === 'OK' && rep.data) {

      this.initLists(rep.data);

      if(this.isFormReady()){
        this.isReady.emit();
      } 

    } else {
      this.handleError();
    }

  }

  initLists(data: ResponseData) {

    if (data.contacts) {
      this.initContactList(data.contacts);
    }
    else if (data.entites) {
      this.initEntityList(data.entites);
    }
    else if (data.users) {
      this.initUserList(data.users);
    }
  }

  isFormReady(): boolean{
    return this.contacts && this.entitis && this.users ? true : false;
  }

  initValidators() {
    this.form.controls.dossierRef.setValidators([Validators.maxLength(256)]);
    this.form.controls.dossierName.setValidators([Validators.maxLength(256), RegexValidator.alfNamePattern()]);
  }

  initContactList(contacts: ContactInt[]) {
    this.contacts = contacts.map(contact => `${contact.prenom}  ${contact.nom} (${contact.courriel})`);
    this.form.controls.contact.setValidators([ListValidator.inListValidator(this.contacts)]);
  }

  initEntityList(entites: EntityInt[]) {
    this.entitis = entites.map(entity => entity.nom);
    this.form.controls.entity.setValidators([ListValidator.inListValidator(this.entitis)]);
  }

  initUserList(users: User[]) {
    
    this.users = users.map(user => new User(user));
    ['missionHead'].forEach(ctlName => {
      this.form.controls[ctlName].setValidators([ListValidator.inListValidator(this.users)]);
    });
  }

  //TODO MAke global fonction
  getMessage(formControlName: string): string | undefined {

    const errors = this.form.get(formControlName).errors;

    if (errors?.required) {
      return 'Ce champ est obligatoire';
    }
    if (errors?.alfNamePattern) {
      return `Ce champ ne peut pas se terminer par un point ou un espace. 
              Ce champ ne peut pas contenir les caractères suivants : "*/><?:`;
    }
  }

  handleError() {
    this.isReady.emit();
    this.isServerError.emit();
  }

}
