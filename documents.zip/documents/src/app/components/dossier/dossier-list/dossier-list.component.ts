/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Injectable, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';

import { of } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';

import { Dossier } from 'app/model/dossier';
import { DossierService } from 'app/services/dossier.service';
import { UserPermissions } from 'app/model/permissions';
import { UserService } from 'app/services/user.service';



@Injectable({
  providedIn: 'root'
})
export class MatPaginatorIntlFR extends MatPaginatorIntl {

  itemsPerPageLabel = 'Dossiers par page';
  nextPageLabel = 'Page Prochaine';
  previousPageLabel = 'Page Précedente';

}

@Component({
  selector: 'app-dossier-list',
  templateUrl: './dossier-list.component.html',
  styleUrls: ['./dossier-list.component.css'],
  providers: [{ provide: MatPaginatorIntl, useClass: MatPaginatorIntlFR }]
})

export class DossierListComponent {

  permissions: UserPermissions = new UserPermissions(null); 

  resultsLength = 0;

  isLoadingResults = true;

  isServerError = false;

  displayedColumns = ['ref', 'name', 'link'];

  dataSource = new MatTableDataSource<Dossier>();

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private readonly dossierService: DossierService,
    private readonly userService : UserService,
    private readonly router: Router
    ) { 

      this.userService.getUserPermission().subscribe(
        rep => {
          this.isLoadingResults = false;
          if (rep.statut === 'OK' && rep.data) {
            this.permissions = new UserPermissions(rep.data);
          }else{
            this.permissions = null;
          }
        },
        err => {
          this.isLoadingResults = false;
          this.isServerError = true;
        }
      );

    }

  ngOnInit(): void {
    //TODO make list of dossier in other component with is ready event
  }

  ngAfterViewInit() {

      if(this.permissions){

        this.dataSource.paginator = this.paginator;

        this.paginator.page.pipe(
          startWith({}),
          switchMap(() => {
            this.isLoadingResults = true;
            return this.dossierService.getDossierEnCoursList(this.paginator.pageSize, this.paginator.pageIndex + 1);
          }),
          map(rep => {
    
            if (rep.statut === 'OK') {
    
              this.resultsLength = rep.data.total;
              return rep.data.dossiers;
    
            } else {
              this.isServerError = true;
              return [];
            }
          }),
          catchError(err => {
            this.handleError();
            return of([]);
          })
        ).subscribe(
          data => {
            this.dataSource = new MatTableDataSource<Dossier>(data);
            this.isLoadingResults = false;
          }
          );
      }
      
  }

  handleError() {
    this.resultsLength = 0;
    this.isLoadingResults = false;
    this.isServerError = true;
  }

  openWS(dossier: Dossier) {
    this.router.navigate(['/dossier', dossier.refDossier, 1]);
  }

  openDashboard(dossier: Dossier) {
    this.router.navigate(['/dossier', dossier.refDossier, 0]);
  }






}
