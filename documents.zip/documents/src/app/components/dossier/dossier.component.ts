/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserPermissions } from 'app/model/permissions';
import { UserService } from 'app/services/user.service';

@Component({
  selector: 'app-dossier',
  templateUrl: './dossier.component.html',
  styleUrls: ['./dossier.component.css']
})
export class DossierComponent implements OnInit {

  dossierRef: string;

  nodeId: string;

  currentDossierId: string;

  selectedTab: (0 | 1) = 0;

  isServerError = false;

  isLoadingResults = false;

  permissions: UserPermissions = new UserPermissions(null); 

  constructor(
    private readonly router: Router,
    private readonly userService : UserService,
    private readonly activatedRoute: ActivatedRoute
  ) {

    this.activatedRoute.paramMap
      .subscribe(
        paramMap => {
          this.dossierRef = paramMap.get('dossierRef');
          const tabIndx = paramMap.get('tabIndx');
          
          this.selectedTab = Number(tabIndx) === 1 ? 1 : 0;

          if( this.router.getCurrentNavigation()?.extras?.state){
            this.currentDossierId = this.router.getCurrentNavigation()?.extras?.state?.toString();
          }else{
            this.currentDossierId = this.dossierRef;
          }
        },
        err => {
          this.handleError();
        }
      );

      this.userService.getUserPermission().subscribe(
        rep => {
          this.isLoadingResults = false;
          if (rep.statut === 'OK' && rep.data) {
            this.permissions = new UserPermissions(rep.data);
          }else{
            this.permissions = null;
          }
        },
        err => {
          this.handleError();
        }
      );
  }

  /* setTab(event){
    this.selectedTab = event;
  } */

  ngOnInit(): void {
  }

  handleError() {
    this.isLoadingResults = false;
    this.isServerError = true;
  }

}
