/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { NotificationService } from '@alfresco/adf-core';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { saveAs } from 'file-saver';

import { DemandeDialogComponent } from 'app/components/demande/demande-dialog/demande-dialog.component';
import { Demande, SendDempandeResponse } from 'app/model/demande';
import { DemandeService } from 'app/services/demande.service';
import { SentDemandesStatusComponent } from './sent-demandes-status/sent-demandes-status.component';
import { DossierService } from 'app/services/dossier.service';
import { TranslateService } from '@ngx-translate/core';

export interface Stats {
  'en-attente-de-reponse': number
  'en-cours-d-envoi': number,
  'envoyees': number,
  'non-envoyees': number
}


@Component({
  selector: 'app-dossier-dashboard',
  templateUrl: './dossier-dashboard.component.html',
  styleUrls: ['./dossier-dashboard.component.css']
})
export class DossierDashboardComponent implements OnInit {

  @Input()
  currentDossierId: string;

  @Input()
  dossierRef: string;

  direction: 'DEN' | 'DC';

  isServerError = false;

  isLoadingResults = true;

  demandesList: Demande[] = [];

  selectedDemandes: Demande[] = [];

  permissions: { stats: string[]; demandes: string[] };

  properties: {
    label: string,
    value: string | number
  }[];

  stats: Stats = null;


  constructor(
    public dialog: MatDialog,
    private readonly dossierService: DossierService,
    private readonly notificationService: NotificationService,
    private readonly translateService: TranslateService,
    private readonly demandeService: DemandeService
  ) { }

  ngOnInit(): void {

    this.demandeService.getDemandeList(this.currentDossierId).subscribe(
      rep => {

        if (rep.statut === 'OK' && rep.data) {
          this.isLoadingResults = false;
          this.demandesList = rep.data.demandes ? rep.data.demandes.map(demande => new Demande(demande)) : [];
          this.stats = rep.data.stats ? rep.data.stats : null;
          this.permissions = rep.data.permissions;
          this.direction = rep.data.direction;
          this.properties = this.getPropsToDisplay();
        } else {
          this.handleError();
        }
      },
      err => {
        this.handleError();
      }
    );

  }

  hasPemissions(partName: 'stats' | 'demandesList' | 'newDemande'): boolean | undefined {

    switch (partName) {
      case 'stats':
        return this.permissions.stats.indexOf('READ') !== -1;
      case 'demandesList':
        return this.permissions.demandes.indexOf('READ') !== -1;
      case 'newDemande':
        return this.permissions.demandes.indexOf('ADD') !== -1;
    }

  }


  openDemandeDialog(): void {
    const dialogRef = this.dialog.open(DemandeDialogComponent, {
      width: '50%',
      data: { dossierRef: this.dossierRef, mode: 'create', direction: this.direction }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
      if (result && result.data.refDemande) {
        this.notificationService
          .showInfo(`Demande ${result.data.refDemande} créée avec succès`);
      }
    });
  }

  setSelectesDemandes(selectedList: Demande[]) {
    this.selectedDemandes = selectedList;
  }

  isSelectedDemandes(): boolean {
    const savedDemandes = this.selectedDemandes.filter(demande => demande.status === 'Sauvegardée');
    return savedDemandes.length > 0;
  }

  sendDemandes() {

    const savedDemandes = this.selectedDemandes.filter(demande => demande.status === 'Sauvegardée');

    this.demandeService.sendDemandes(savedDemandes.map(demande => demande.number)).subscribe(
      rep => {

        if (rep.reponses) {
          const responses = rep.reponses.map(response => new SendDempandeResponse(response));
          this.openSendDemandeDialog(responses);
        } else {
          this.notificationService
            .showError(`Une erreur technique s'est produite. Merci de contacter l'administrateur de l'application.`);
        }

      },
      err => {
        this.notificationService
          .showError(`Une erreur technique s'est produite. Merci de contacter l'administrateur de l'application.`);
      }
    );

  }

  openSendDemandeDialog(responses: SendDempandeResponse[]): void {
    const dialogRef = this.dialog.open(SentDemandesStatusComponent, {
      width: '50%',
      data: { responses: responses }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.selectedDemandes = [];
      this.ngOnInit();
    });
  }

  extractInventoryBase() {

    this.dossierService.getInventoryBase(this.dossierRef).subscribe(
      rep =>{
        let filename: string;
        try{
          filename = rep.headers.get('content-disposition').split("filename=")[1];
        }finally{
          if(!filename){
            filename = this.translateService.instant('SIDEC.DOSSIER.DEFAULT_INVENTORY_FILENAME');
          }
        }     
        saveAs(rep.body, filename);
      },
      err =>{
        this.notificationService.showError(`Problème technique en serveur. Merci de contacter l'administrateur de l'application.`)
        throw err;
      }

    );
  }

  b64StringToBlob(b64Data: string, mimetype: string): Blob{
    const byteCharacters = atob(b64Data);

    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }

    const byteArray = new Uint8Array(byteNumbers);

    return new Blob([byteArray], { type: mimetype });
  }

  getPropsToDisplay() {
    return [
      {
        label: 'SIDEC.DEMANDES.NOT_SENT',
        value: this.stats !== null ? this.stats['non-envoyees'] : 'XX'
      },
      {
        label: 'SIDEC.DEMANDES.SENDING',
        value: this.stats !== null ? this.stats['en-cours-d-envoi'] : 'XX'
      },
      {
        label: 'SIDEC.DEMANDES.SENT',
        value: this.stats !== null ? this.stats.envoyees : 'XX'
      },
      {
        label: 'SIDEC.DEMANDES.WAITING',
        value: this.stats !== null ? this.stats['en-attente-de-reponse'] : 'XX'
      }
    ];
  }

  handleError() {
    this.isLoadingResults = false;
    this.isServerError = true;
  }

}
