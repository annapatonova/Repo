import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DossierDashboardComponent } from './dossier-dashboard.component';

describe('DossierDashboardComponent', () => {
  let component: DossierDashboardComponent;
  let fixture: ComponentFixture<DossierDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DossierDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DossierDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
