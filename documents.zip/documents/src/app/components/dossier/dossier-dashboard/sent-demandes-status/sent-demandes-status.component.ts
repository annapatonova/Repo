/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';

import { SendDempandeResponse } from 'app/model/demande';


@Component({
  selector: 'app-sent-demandes-status',
  templateUrl: './sent-demandes-status.component.html',
  styleUrls: ['./sent-demandes-status.component.css']
})
export class SentDemandesStatusComponent implements OnInit {

  isLoadingResults = true;
  isServerError = false;

  displayedColumns = ['number', 'name', 'message', 'status'];
  dataSource = new MatTableDataSource<SendDempandeResponse>();

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { responses: SendDempandeResponse[]},
    public readonly dialogRef: MatDialogRef<SendDempandeResponse>
  ) { }

  ngOnInit(): void {

    if (this.data.responses) {
      this.dataSource = new MatTableDataSource<SendDempandeResponse>(this.data.responses);
      this.isLoadingResults = false;
    }else{
      this.isLoadingResults = false;
      this.isServerError = true;
    }

  }

  onCloseClick(): void {
    this.dialogRef.close();
}

}
