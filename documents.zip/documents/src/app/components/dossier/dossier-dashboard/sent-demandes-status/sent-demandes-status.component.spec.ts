import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SentDemandesStatusComponent } from './sent-demandes-status.component';

describe('SentDemandesStatusComponent', () => {
  let component: SentDemandesStatusComponent;
  let fixture: ComponentFixture<SentDemandesStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SentDemandesStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SentDemandesStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
