/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

import { NotificationService } from '@alfresco/adf-core';

import { FileUploadComponent } from 'app/widgets/file-upload/file-upload.component';
import { DossierService } from 'app/services/dossier.service';
import { UserPermissions } from 'app/model/permissions';
import { UserService } from 'app/services/user.service';


@Component({
  selector: 'app-create-dossier',
  templateUrl: './create-dossier.component.html',
  styleUrls: ['./create-dossier.component.css']
})
export class CreateDossierComponent implements OnInit {

  @ViewChild(FileUploadComponent) uploader: FileUploadComponent;

  profileForm: FormGroup = new FormGroup({});

  isLoadingResults = true;

  isServerError = false;

  permissions: UserPermissions = new UserPermissions(null);

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly dossierService: DossierService,
    private readonly notificationService: NotificationService,
    private readonly userService: UserService,
    private readonly router: Router
  ) {

    this.userService.getUserPermission().subscribe(
      rep => {
        if (rep.statut === 'OK' && rep.data) {
          this.permissions = new UserPermissions(rep.data);
          this.permissions = this.permissions?.canCreateDossier() ? this.permissions : null;
        } else {
          this.permissions = null;
          this.isLoadingResults = false;
        }
      },
      err => {
        this.setServerError();
      }
    );
  }

  ngOnInit(): void {

    this.isLoadingResults = true;

    this.profileForm = this.formBuilder.group({
      dossierRef: new FormControl(''),
      dossierName: new FormControl(''),
      dossierOpenDate: new FormControl(new Date()),
      entity: new FormControl(''),
      contact: new FormControl(''),
      missionHead: new FormControl(''),
      otherDossierCharged: new FormControl([])
    });

  }



  onSubmit() {

    if (this.profileForm.valid) {

      this.isLoadingResults = true;

      this.dossierService.createDossier(this.profileForm.value, this.uploader.getFiles()).subscribe(
        rep => {

          if (rep.statut === 'OK') {
            this.isLoadingResults = false;
            this.router.navigate(['/dossier', this.profileForm.value.dossierRef, 1], { state: rep.data.nodeId });
            this.notificationService
              .showInfo('Dossier créé avec succès');
          } else {
            this.handleError(rep.message.toString());
          }

        },
        err => {
          this.handleError("Une erreur technique s'est produite. Merci de contacter l'administrateur de l'application.");
        }

      );
    }

  }

  handleError(err: string) {
    this.isLoadingResults = false;
    this.notificationService.showError(err);
  }

  setReady() {
    this.isLoadingResults = false;
  }

  setServerError() {
    this.isLoadingResults = false;
    this.isServerError = true;
  }

}
