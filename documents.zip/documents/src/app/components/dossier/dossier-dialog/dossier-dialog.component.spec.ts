import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DossierDialogComponent } from './dossier-dialog.component';

describe('DossierDialogComponent', () => {
  let component: DossierDialogComponent;
  let fixture: ComponentFixture<DossierDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DossierDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DossierDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
