/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { NotificationService } from '@alfresco/adf-core';

import { Dossier } from 'app/model/dossier';
import { DossierService } from 'app/services/dossier.service';
import { Permission } from 'app/model/commons';

@Component({
  selector: 'app-dossier-dialog.component',
  templateUrl: 'dossier-dialog.component.html',
  styleUrls: ['dossier-dialog.component.css']
})
export class DossierDialogComponent implements OnInit {

  profileForm: FormGroup;

  isLoadingResults = true;

  isServerError = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public dossier: Dossier,
    private readonly notificationService: NotificationService,
    private readonly formBuilder: FormBuilder,
    private readonly dossierService: DossierService,
    public readonly dialogRef: MatDialogRef<DossierDialogComponent>
  ) {

  }

  ngOnInit(): void {
    this.profileForm = this.formBuilder.group({
      dossierRef: new FormControl(this.dossier.refDossier),
      dossierName: new FormControl(this.dossier.name),
      dossierOpenDate: new FormControl(this.dossier.dateOuvertureDossier),
      entity: new FormControl(this.dossier.entiteDossier),
      contact: new FormControl(this.dossier.contactDossier),
      missionHead: new FormControl(this.dossier.missionHead),
      otherDossierCharged: new FormControl(this.dossier.otherDossierCharged),
      statutCtrl: new FormControl(this.dossier.statutDossier)
    });
  }

  canModifyStatut() {
    return this.dossier.permissions.statutDossier.indexOf(Permission.UPDATE) >= 0;
  }

  setReady() {
    this.isLoadingResults = false;
  }

  setServerError() {
    this.isLoadingResults = false;
    this.isServerError = true;
  }

  onSubmit() {
    if (this.profileForm.valid) {
      this.isLoadingResults = true;
      this.dossierService.updateDossier(this.profileForm.value).subscribe(
        rep => {
          if (rep.statut === 'OK') {
            this.dialogRef.close();
          } else {
            this.handleError(rep.message);
          }
        },
        err => {
          this.handleError("Une erreur technique s'est produite. Merci de contacter l'administrateur de l'application.");
        }

      );
    }
  }

  handleError(err: string) {
    this.isLoadingResults = false;
    this.notificationService.showError(err);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}