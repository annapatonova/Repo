/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';

import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { NotificationService } from '@alfresco/adf-core';

import { Dossier, DossierInt } from 'app/model/dossier';
import { DossierService } from 'app/services/dossier.service';
import { DossierDialogComponent } from '../dossier-dialog/dossier-dialog.component';
import { DateFR } from 'app/model/dates';
import { User } from 'app/model/users';


@Component({
  selector: 'app-dossier-workspace',
  templateUrl: './dossier-workspace.component.html',
  styleUrls: ['./dossier-workspace.component.css']
})

export class DossierWorkspaceComponent implements OnInit {

  @Input()
  currentDossierId: string;

  dossier: Dossier;

  isLoadingResults = true;

  isServerError = false;

  properties: {
    label: string,
    value: string | DateFR | User
  }[];
  
  nodeId: string;

  constructor(
    public dialog: MatDialog,
    private readonly dossierService: DossierService,
    private readonly notificationService: NotificationService
  ) {
 
  }
 
  ngOnInit(): void {

    this.dossierService.getDossierProperies(this.currentDossierId).subscribe(
      rep =>{

        if (rep.statut === 'OK') {
          this.isLoadingResults = false;

          let dossierInt: DossierInt;
          dossierInt = rep.data.props;
          dossierInt.permissions = rep.data.permissions;
          dossierInt.direction = rep.data.direction;
          this.dossier = new Dossier(dossierInt);

          this.properties = this.getPropsToDisplay(this.dossier);
        } else {
          this.handleError();
        }

      },
      err =>{
        this.handleError();
      }
    );

  }

  handleError(){
    this.isLoadingResults = false;
    this.isServerError = true;
  }

  openDossierDialog(): void {
    const dialogRef = this.dialog.open(DossierDialogComponent, {
      data: this.dossier
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
      if (result && result.message) {
        this.notificationService
          .showInfo(result.message);
      }
    });
  }

  getPropsToDisplay(dossier: Dossier){
    return [
      {
        label: 'SIDEC.DOSSIER.REF',
        value: dossier.refDossier
      },
      {
        label: 'SIDEC.DOSSIER.NAME',
        value: dossier.name
      },
      {
        label: 'SIDEC.DOSSIER.OPEN_DATE',
        value: dossier.dateOuvertureDossier
      },
      {
        label: 'SIDEC.DOSSIER.STATUT',
        value: dossier.statutDossier
      },
      {
        label: 'SIDEC.DOSSIER.ENTITY',
        value: dossier.entiteDossier
      },
      {
        label: 'SIDEC.DOSSIER.CONTACT',
        value: dossier.contactDossier
      },
      {
        label: 'SIDEC.DOSSIER.CHARGED_1',
        value: dossier.missionHead
      },
      {
        label: 'SIDEC.DOSSIER.CHARGED_2',
        value: dossier.displayOtherDossierCharged()
      }
    ];
  }

}
