import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DossierWorkspaceComponent } from './dossier-workspace.component';

describe('DossierWorkspaceComponent', () => {
  let component: DossierWorkspaceComponent;
  let fixture: ComponentFixture<DossierWorkspaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DossierWorkspaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DossierWorkspaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
