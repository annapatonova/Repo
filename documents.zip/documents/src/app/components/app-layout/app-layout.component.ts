/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserPermissions } from 'app/model/permissions';

import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app-layout.component.html',
  styleUrls: ['./app-layout.component.css']
})
export class AppLayoutComponent {

  username : string;

  permissions: UserPermissions;
  constructor(
    private readonly userService : UserService,
    private readonly router: Router
    ) {

      this.userService.getUserPermission().subscribe(
        rep => {
          if(rep.statut === 'OK' && rep.data){
            this.permissions = new UserPermissions(rep.data);
          }else{
            this.router.navigate(['/home']);
          }
        }
      );
      
  }

  ngOnInit() {
    this.username = this.userService.getCurrentUsername();
  }

  goHomePage(){
    if(this.permissions){
      this.router.navigate(['/dossiers']);
    }
    
  }


}
