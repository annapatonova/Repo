/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component } from '@angular/core';
import {environment} from '../../../environments/environment';

//TODO TMP example of application version

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  currentApplicationVersion = environment.appVersion;
}
