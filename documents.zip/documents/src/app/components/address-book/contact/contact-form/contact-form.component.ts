/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { EventEmitter, Input, Output, Component, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';

import { AddressBookService } from 'app/services/address-book.service';
import { merge } from 'rxjs';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {

  @Input()
  mode: 'edit' | 'create' = 'create';

  @Input() fg: FormGroup;

  @Output()
  ready = new EventEmitter<void>();

  @Output()
  serverError = new EventEmitter<void>();

  private isCountries: boolean;

  listStatut: ('Actif' | 'Inactif')[];

  civilityList: string[];

  listEntities: string[];

  constructor(
    private readonly adressBookService: AddressBookService
  ) { }

  ngOnInit(): void {

    this.initValidators();

    this.listStatut = ['Actif', 'Inactif'];

    merge(
      this.adressBookService.getCivilities(),
      this.adressBookService.getEtitiesActives()
    ).subscribe(
      rep => {
        if (rep.statut === 'OK' && rep.data) {

          if (rep.data.entites) {
            this.listEntities = rep.data.entites.map(entity => entity.nom);
          }

          if (rep.data.civilites) {
            this.civilityList = rep.data.civilites.map(civility => civility.abreviation);
          }

          this.setReady();

        } else {
          this.serverError.emit();
        }
      },
      err => {
        this.handleError();
      }
    );

  }
  
  initValidators() {

    this.fg.controls.email.setValidators([Validators.email]);

    this.fg.get('address').setValidators([Validators.maxLength(1024)]);

    this.fg.get('function').setValidators([Validators.maxLength(512)]);

    ['lastName', 'firstName', 'city'].forEach(ctlName => {
      this.fg.get(ctlName).setValidators([Validators.maxLength(256)]);
    });

    ['civility', 'zipCode'].forEach(ctlName => {
      this.fg.get(ctlName).setValidators([Validators.maxLength(32)]);
    });

    ['phone', 'fax'].forEach(ctlName => {
      this.fg.get(ctlName).setValidators([Validators.pattern('^(\\+)?[0-9]*'), Validators.maxLength(128)]);
    });

  }

  handleError() {
    this.ready.emit();
    this.serverError.emit();
  }

  countriesReady() {
    this.isCountries = true;
    this.setReady();
  }

  setReady() {
    if (this.listEntities && this.civilityList && this.isCountries) {
      this.ready.emit();
    }
  }

  setServerError() {
    this.serverError.emit();
  }

}
