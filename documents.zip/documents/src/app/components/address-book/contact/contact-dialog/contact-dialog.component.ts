/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { NotificationService } from '@alfresco/adf-core';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { Contact } from 'app/model/adress-book';
import { AddressBookService } from 'app/services/address-book.service';

@Component({
    selector: 'app-contact-dialog',
    templateUrl: './contact-dialog.component.html',
    styleUrls: ['./contact-dialog.component.css']
})
export class ContactDialogComponent implements OnInit {
    profileForm: FormGroup;

    isLoadingResults = true;

    isServerError = false;

    contact: Contact = new Contact(
        {
            nom: '',
            prenom: '',
            civilite: '',
            courriel: '',
            fonction: '',
            code_postal: '',
            ville: '',
            adresse_postale: '',
            telephone: '',
            telecopie: '',
            statut: 'Actif',
            entites: [],
            pays: ''
        }
    );

    mode: 'create' | 'edit' = 'create';

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: { mode: 'create' | 'edit', contact: Contact },
        private readonly notificationService: NotificationService,
        private readonly formBuilder: FormBuilder,
        private readonly adressBookService: AddressBookService,
        public readonly dialogRef: MatDialogRef<ContactDialogComponent>) {

    }

    ngOnInit(): void {

        if (this.data && this.data.contact) {
            this.contact = this.data.contact;
        }

        if (this.data && this.data.mode) {
            this.mode = this.data.mode;
        }

        this.profileForm = this.formBuilder.group({
            civility: new FormControl(this.contact.civilite),
            lastName: new FormControl(this.contact.nom),
            firstName: new FormControl(this.contact.prenom),
            email: new FormControl(this.contact.courriel),
            entities: new FormControl(this.contact.entites.map(entity => entity.nom)),
            function: new FormControl(this.contact.fonction),
            address: new FormControl(this.contact.adresse_postale),
            zipCode: new FormControl(this.contact.code_postal),
            city: new FormControl(this.contact.ville),
            country: new FormControl(this.contact.pays),
            phone: new FormControl(this.contact.telephone),
            fax: new FormControl(this.contact.telecopie),
            statut: new FormControl(this.contact.statut)
        });

    }

    onSaveContact(): void {

        if (this.profileForm.valid) {
            this.isLoadingResults = true;
            const data = this.profileForm.value;
            switch (this.mode) {
                case 'create': {
                    this.adressBookService.createContact(data).subscribe(
                        rep => { this.succeed(rep); },
                        err => { this.handleError(err); }
                    );
                    break;
                }
                case 'edit': {
                    this.adressBookService.updateContact(data).subscribe(
                        rep => { this.succeed(rep); },
                        err => { this.handleError(err); }
                    );
                    break;
                }
            }
        }
    }

    succeed(rep: any) {
        if (rep.statut === 'OK') {
            this.dialogRef.close(rep);
        } else {
            this.isLoadingResults = false;
            this.notificationService
                .showError(`${rep.message}`);
        }
    }

    handleError(err: any) {
        this.isLoadingResults = false;
        this.notificationService
            .showError("Problème technique en serveur. Merci de contacter l'administrateur de l'application.");
        throw err;
    }

    onNoClick(): void {
        this.dialogRef.close();
    }

    setReady() {
        this.isLoadingResults = false;
    }

    setServerError() {
        this.isLoadingResults = false;
        this.isServerError = true;
    }
}
