/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { NotificationService } from '@alfresco/adf-core';

import { of } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';

import { Contact } from 'app/model/adress-book';
import { AddressBookService } from 'app/services/address-book.service';
import { ContactDialogComponent } from './contact-dialog/contact-dialog.component';
import { UserPermissions } from 'app/model/permissions';
import { UserService } from 'app/services/user.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  contact: Contact;
  permissions: UserPermissions= new UserPermissions(null);
  currentContactMail: string;
  isLoadingResults = true;
  isServerError = false;
  properties: { label: string; value: string; }[];
  address: { label: string; value: string; }[];
  contactInfo: { label: string; value: string; }[];

  constructor(
    public dialog: MatDialog,
    private readonly addressBookService: AddressBookService,
    private readonly userService : UserService,
    private readonly route: ActivatedRoute,
    private readonly notificationService: NotificationService
  ) {

    this.userService.getUserPermission().subscribe(
      rep => {
        this.isLoadingResults = false;
        if (rep.statut === 'OK' && rep.data) {
          this.permissions = new UserPermissions(rep.data);
        }else{
          this.permissions = null;
        }
      },
      err => {
        this.isLoadingResults = false;
        this.isServerError = true;
      }
    );
    
}

  ngOnInit(): void {

    this.route.queryParams.pipe(
      map(
        params => {
          const email = params.email;
          if (email != null) {
            this.currentContactMail = email;
          }else{
            this.isServerError = true;
            this.isLoadingResults = false;
          }
        }
      ),
      switchMap(() => {
        return this.addressBookService.getContact(this.currentContactMail);
      }),
      map(rep => {
        let contact: Contact;

        this.isLoadingResults = false;

        if (rep.statut === 'OK') {
          contact = rep.data.contact;
          
        } else {
          this.isServerError = true;
        }

        return contact;
      }),
      catchError(err => {
        this.isLoadingResults = false;
        this.isServerError = true;
        return of(null);
      })
    ).subscribe(data => {
      if(!this.isServerError && data){
        this.contact = new Contact(data);
        this.properties = this.getPropsToDisplay(); 
        this.address = this.getAddresseToDisplay(); 
        this.contactInfo = this.getContactInfo();
      }
    });
  }
  getContactInfo(): { label: string; value: string; }[] {
    return [
      {
        label: 'SIDEC.CONTACT.EMAIL',
        value: this.contact.courriel
      },
      {
        label: 'SIDEC.CONTACT.PHONE',
        value: this.contact.telephone
      },
      {
        label: 'SIDEC.CONTACT.FAX',
        value: this.contact.telecopie
      }
    ];
  }

  openContactDialog(): void {
    const dialogRef = this.dialog.open(ContactDialogComponent, {
      data: { contact: this.contact, mode: 'edit' },
      width: '50%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result.message) {
        this.ngOnInit();
        this.notificationService
          .showInfo(result.message);
      }
    });
  }


  getPropsToDisplay(){
    return [
      {
        label: 'SIDEC.CONTACT.CIVILITY',
        value: this.contact.civilite
      },
      {
        label: 'SIDEC.CONTACT.LAST_NAME',
        value: this.contact.nom
      },
      {
        label: 'SIDEC.CONTACT.FIRST_NAME',
        value: this.contact.prenom
      },
      {
        label: 'SIDEC.CONTACT.FUNCTION',
        value: this.contact.fonction
      },
      {
        label: 'SIDEC.CONTACT.STATUS',
        value: this.contact.statut
      }
    ];
  }

  getAddresseToDisplay(){
    return [
      {
        label: 'SIDEC.CONTACT.ADDRESS',
        value: this.contact.adresse_postale
      },
      {
        label: 'SIDEC.CONTACT.ZIPCODE',
        value: this.contact.code_postal
      },
      {
        label: 'SIDEC.CONTACT.CITY',
        value: this.contact.ville
      },
      {
        label: 'SIDEC.COUNTRY',
        value: this.contact.pays
      }
    ];
  }


}
