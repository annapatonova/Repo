/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Injectable, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';

import { of } from 'rxjs';
import { startWith, switchMap, map, catchError } from 'rxjs/operators';

import { Contact } from 'app/model/adress-book';
import { AddressBookService } from 'app/services/address-book.service';

@Injectable({
  providedIn: 'root'
})
export class MatPaginatorIntlFR extends MatPaginatorIntl {
  itemsPerPageLabel = 'Contacts par page';
  nextPageLabel = 'Page Prochaine';
  previousPageLabel = 'Page Précedente';
}

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css'],
  providers: [{ provide: MatPaginatorIntl, useClass: MatPaginatorIntlFR }]
})
export class ContactListComponent {

  @Input()
  contacts: Contact[];

  @Input()
  statut: 'Actif' | 'Inactif';

  @Input()
  name: string;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  dataSource = new MatTableDataSource<Contact>();

  displayedColumns =
     ['civility', 'lastName', 'firstName', 'email', 'phone', 'fonction', 'status', 'link'];

  resultsLength = 0;

  isLoadingResults = true;

  isServerError = false;


  constructor(
    private readonly adressBookService: AddressBookService,
    private readonly router: Router
  ) { }

  
  

  ngOnChanges(changes: SimpleChanges): void {
    this.ngAfterViewInit();
  }

  ngAfterViewInit(): void {

    if (this.contacts) {
      this.dataSource = new MatTableDataSource<Contact>(this.contacts);
    }

    this.dataSource.paginator = this.paginator;

    if (!this.contacts) {
      this.paginator.page.pipe(
        startWith({}),
        switchMap(() => {
          this.isLoadingResults = true;
          return this.adressBookService.getContacts(this.paginator.pageSize, this.paginator.pageIndex + 1, this.name, this.statut);
        }),
        map(rep => {

          this.isLoadingResults = false;

          if (rep.statut === 'OK') {

            this.resultsLength = rep.data.total;
            return rep.data.contacts;

          } else {
            this.isServerError = true;
            return [];
          }
        }),
        catchError(err => {
          this.resultsLength = 0;
          this.isLoadingResults = false;
          this.isServerError = true;
          return of([]);
        })
      ).subscribe(
        data => this.dataSource = new MatTableDataSource<Contact>(data)
      );
    }

  }

  showContact(contact: Contact) {
    this.router.navigate(['/contact'], { queryParams: { email: contact.courriel } });

  }
}
