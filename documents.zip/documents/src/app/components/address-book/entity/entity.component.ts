/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { NotificationService } from '@alfresco/adf-core';

import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';

import { Entity } from 'app/model/adress-book';
import { AddressBookService } from 'app/services/address-book.service';
import { EntityDialogComponent } from './entity-dialog/entity-dialog.component';
import { UserService } from 'app/services/user.service';
import { UserPermissions } from 'app/model/permissions';

@Component({
  selector: 'app-entity',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.css']
})
export class EntityComponent implements OnInit {

  entity: Entity;
 
  currentEntityName: string;

  isLoadingResults = true;

  isServerError = false;

  permissions: UserPermissions= new UserPermissions(null);

  properties: { label: string; value: string; }[];

  address: { label: string; value: string; }[];

  constructor(
    public readonly dialog: MatDialog,
    private readonly addressBookService: AddressBookService,
    private readonly userService : UserService,
    private readonly route: ActivatedRoute,
    private readonly notificationService: NotificationService
  ) {

    this.userService.getUserPermission().subscribe(
      rep => {
        this.isLoadingResults = false;
        if (rep.statut === 'OK' && rep.data) {
          this.permissions = new UserPermissions(rep.data);
        }else{
          this.permissions = null;
        }
      },
      err => {
        this.isLoadingResults = false;
        this.isServerError = true;
      }
    );
    
}

  ngOnInit(): void {

    this.route.queryParams.pipe(
      map(
        params => {
          const name = params.name;
          if (name != null) {
            this.currentEntityName = name;
          }else{
            this.isServerError = true;
            this.isLoadingResults = false;
          }
        }
      ),
      switchMap(() => {
        return this.addressBookService.getEntity(this.currentEntityName);
      }),
      map(rep => {
        let entity: Entity;

        this.isLoadingResults = false;

        if (rep.statut === 'OK') {
          entity = rep.data.entite;
          
        } else {
          this.isServerError = true;
        }

        return entity;
      }),
      catchError(err => {
        this.isLoadingResults = false;
        this.isServerError = true;
        return of(null);
      })
    ).subscribe(data => {
      if(!this.isServerError && data){
        this.entity = new Entity(data);
        this.properties = this.getPropsToDisplay(); 
        this.address = this.getAddresseToDisplay();
      }
    });
  }

  openEntityDialog(): void {
    const dialogRef = this.dialog.open(EntityDialogComponent, {
      data: { entity: this.entity, mode: 'edit' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result.message) {
        this.ngOnInit();
        this.notificationService
          .showInfo(result.message);
      }
    });
  }


  getPropsToDisplay(){
    return [
      {
        label: 'SIDEC.ENTITY.NAME',
        value: this.entity.nom
      },
      {
        label: 'SIDEC.ENTITY.PHONE',
        value: this.entity.telephone
      },
      {
        label: 'SIDEC.ENTITY.STATUS',
        value: this.entity.statut
      }
    ];
  }

  getAddresseToDisplay(){
    return [
      {
        label: 'SIDEC.ENTITY.ADDRESS',
        value: this.entity.adresse_postale
      },
      {
        label: 'SIDEC.ENTITY.ZIPCODE',
        value: this.entity.code_postal
      },
      {
        label: 'SIDEC.ENTITY.CITY',
        value: this.entity.ville
      },
      {
        label: 'SIDEC.COUNTRY',
        value: this.entity.pays
      }
    ];
  }

}
