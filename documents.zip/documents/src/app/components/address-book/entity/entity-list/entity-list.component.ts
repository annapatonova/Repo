/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */

import { Component, EventEmitter, Injectable, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Entity } from 'app/model/adress-book';
import { AddressBookService } from 'app/services/address-book.service';
import { of } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MatPaginatorIntlFR extends MatPaginatorIntl { 
  itemsPerPageLabel = 'Entités par page'; 
  nextPageLabel = 'Page Prochaine'; 
  previousPageLabel = 'Page Précedente';
}

@Component({
  selector: 'app-entity-list',
  templateUrl: './entity-list.component.html',
  styleUrls: ['./entity-list.component.css'],
  providers: [{ provide: MatPaginatorIntl, useClass: MatPaginatorIntlFR }]
})
export class EntityListComponent implements OnChanges {

  @Input()
  entities: Entity[];

  @Input()
  statut: 'Actif' | 'Inactif';

  @Input()
  name: string;

  @Output() isReady = new EventEmitter<Entity>();

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['name', 'zipCode', 'city', 'country', 'telephone', 'tags', 'link'];

  dataSource = new MatTableDataSource<Entity>();

  resultsLength = 0;

  isLoadingResults = true;

  isServerError = false;

  constructor(
    private readonly adressBookService: AddressBookService,
    private readonly router: Router
  ) { }

  ngOnChanges(changes: SimpleChanges): void {
    this.ngAfterViewInit();
  }

  ngAfterViewInit(): void {

    
    if(this.entities){

      this.dataSource = new MatTableDataSource<Entity>(this.entities);

      this.dataSource.paginator = this.paginator;
    }else{
      this.paginator.page.pipe(
        startWith({}),
        switchMap(() => {
          this.isLoadingResults = true;
          return this.adressBookService.getEtities(this.paginator.pageSize, this.paginator.pageIndex + 1, this.name, this.statut);
        }),
        map(rep => {
  
          this.isLoadingResults = false;
  
          if (rep.statut === 'OK') {
  
            this.resultsLength = rep.data.total;
            const entities: Entity[] = rep.data.entites;
  
            this.isReady.emit();
  
            return entities;
  
          } else {
            this.isReady.emit();
            this.isServerError = true;
            return [];
          }
        }),
        catchError(err => {
          this.resultsLength = 0;
          this.isLoadingResults = false;
          this.isServerError = true;
          return of([]);
        })
      ).subscribe(
        data => this.dataSource = new MatTableDataSource<Entity>(data));

    }
    

  }

  showEntity(entity: Entity) {
    this.router.navigate(['/entity'], { queryParams: { name: entity.nom } });

  }


}
