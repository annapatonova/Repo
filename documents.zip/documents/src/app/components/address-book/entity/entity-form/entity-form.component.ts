/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-entity-form',
  templateUrl: './entity-form.component.html',
  styleUrls: ['./entity-form.component.css']
})
export class EntityFormComponent implements OnInit {

  @Input()
  mode: 'edit' | 'create' = 'create';

  @Input() fg: FormGroup;

  listStatut: ('Actif' | 'Inactif')[] = ['Actif', 'Inactif'];

  @Output()
  isReady = new EventEmitter<void>();

  @Output()
  isServerError = new EventEmitter<void>();

  constructor() {}

  ngOnInit(): void {

    this.initValidators();

  }
  
  initValidators() {

    this.fg.get('zipCode').setValidators([Validators.maxLength(32)]);

    ['name', 'city'].forEach(ctlName =>{
      this.fg.get(ctlName).setValidators([Validators.maxLength(256)]);
    });

    ['address', 'comment'].forEach(ctlName =>{
      this.fg.get(ctlName).setValidators([Validators.maxLength(1024)]);
    });

    this.fg.controls.phone.setValidators([Validators.pattern('^(\\+)?[0-9]*'), Validators.maxLength(128)]);
  }

  setReady() {
    this.isReady.emit();
  }

  setServerError() {
      this.isServerError.emit();
  }

}
