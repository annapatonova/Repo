/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { NotificationService } from '@alfresco/adf-core';

import { UserPermissions } from './../../model/permissions';
import { UserService } from './../../services/user.service';
import { ContactDialogComponent } from './contact/contact-dialog/contact-dialog.component';
import { EntityDialogComponent } from './entity/entity-dialog/entity-dialog.component';
import { EntityListComponent } from './entity/entity-list/entity-list.component';
import { ContactListComponent } from './contact/contact-list/contact-list.component';

@Component({
  selector: 'app-address-book',
  templateUrl: './address-book.component.html',
  styleUrls: ['./address-book.component.css']
})
export class AddressBookComponent implements OnInit {

  nameEntity: string;

  statutEntity: string;

  nameContact: string;

  statutContact: string;

  @ViewChild(EntityListComponent, { static: false }) entityList: EntityListComponent;

  @ViewChild(ContactListComponent, { static: false }) contactList: ContactListComponent;

  canCreate = false;

  listStatut = [null, 'Actif', 'Inactif'];

  isLoadingResults = true;

  isServerError = false;

  permissions: UserPermissions= new UserPermissions(null);

  constructor(
    public readonly dialog: MatDialog,
    private readonly userService: UserService,
    private readonly notificationService: NotificationService) {

    this.userService.getUserPermission().subscribe(
      rep => {
        this.isLoadingResults = false;
        if (rep.statut === 'OK' && rep.data) {
          this.permissions = new UserPermissions(rep.data);
        }else{
          this.permissions = null;
        }
      },
      err => {
        this.isLoadingResults = false;
        this.isServerError = true;
      }
    );

  }

  ngOnInit(): void {

  }

  isReady() {
    this.isLoadingResults = false;
  }

  openEntityDialog(): void {
    const dialogRef = this.dialog.open(EntityDialogComponent, {
      width: '50%'
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
      this.entityList.ngAfterViewInit();
    });
  }

  openContactDialog(): void {
    const dialogRef = this.dialog.open(ContactDialogComponent, {
      width: '50%'
    });

    
    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
      this.contactList.ngAfterViewInit();
    });
  }

  afterCloseDialog(dialogRef: MatDialogRef<EntityDialogComponent | ContactDialogComponent>) {
    dialogRef.afterClosed().subscribe(result => {
      if (result && result.message) {
        this.notificationService
          .showInfo(result.message)
          .afterDismissed()
          .subscribe(() => {
            this.ngOnInit();
          });
      }
    });
  }

}
