/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Injectable, Input,  OnChanges, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { Document } from 'app/model/commons';

@Injectable({
  providedIn: 'root'
})
export class MatPaginatorIntlFR extends MatPaginatorIntl {
  itemsPerPageLabel = 'Documents par page';
  nextPageLabel = 'Page Prochaine';
  previousPageLabel = 'Page Précedente';
}

@Component({
  selector: 'app-document-list',
  templateUrl: './document-list.component.html',
  styleUrls: ['./document-list.component.css'],
  providers: [{ provide: MatPaginatorIntl, useClass: MatPaginatorIntlFR }]
})
export class DocumentListComponent implements OnChanges{

  @Input()
  documents: Document[];

  @ViewChild(MatPaginator) paginator: MatPaginator;

  showViewer = false;

  documentToShowId: string;

  displayedColumns = ['name', 'date', 'user', 'comment', 'tags', 'link'];

  dataSource = new MatTableDataSource<Document>();

  constructor() { }

  ngOnChanges(): void {
    this.init();
  }

  ngAfterViewInit() {
    this.init();
  }

  init(){
    this.dataSource = new MatTableDataSource<Document>(this.documents);

    this.dataSource.paginator = this.paginator;
  }

/*   saveComment(document: Document, event: any){
    console.log(event.target.value);
  }
 */
  showDocument(document: Document){
    this.documentToShowId = document.id;
    this.showViewer = true;
  }

  
}
