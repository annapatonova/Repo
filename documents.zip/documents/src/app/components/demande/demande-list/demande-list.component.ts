/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Injectable, Input, OnChanges, Output, SimpleChanges, ViewChild, EventEmitter } from '@angular/core';
import { state, style, trigger } from '@angular/animations';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';


import { Demande } from 'app/model/demande';

@Injectable({
  providedIn: 'root'
})
export class MatPaginatorIntlFR extends MatPaginatorIntl {

  itemsPerPageLabel = 'Demandes par page';
  nextPageLabel = 'Page Prochaine';
  previousPageLabel = 'Page Précedente';

}

@Component({
  selector: 'app-demande-list',
  templateUrl: './demande-list.component.html',
  styleUrls: ['./demande-list.component.css'],
  providers: [{ provide: MatPaginatorIntl, useClass: MatPaginatorIntlFR }],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' }))
    ])
  ]
})
export class DemandeListComponent implements OnChanges {

  @Input()
  demandes: Demande[];

  @Input()
  selectedDemandes: Demande[] = [];

  @Output()
  selected = new EventEmitter<Demande[]>();

  documentToShowId: string;

  showViewer = false;

  resultsLength = 0;
  isLoadingResults = true;
  isServerError = false;
  displayedColumns = ['check', 'number', 'label', 'recipients', 'date-sent', 'support', 'type', 'status', 'link'];
  dataSource = new MatTableDataSource<Demande>();
  expandedElement: Demande[] = [];
 

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private readonly router: Router) { }


  demandeClick(demande: Demande) {
    const index = this.expandedElement.indexOf(demande);
    if (index >= 0) {
      this.expandedElement.splice(index, 1);
    } else {
      this.expandedElement.push(demande);
    }
  }

  isExpanded(element: Demande): boolean {
    return this.expandedElement.indexOf(element) >= 0;
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.init();
  }

  ngAfterViewInit() {
    this.init();
  }

  init() {

    if (this.demandes) {
      this.dataSource = new MatTableDataSource<Demande>(this.demandes);
    }

    this.dataSource.paginator = this.paginator;

  }

  openDemande(demande: Demande) {
    this.router.navigate(['/demande', demande.number], {state: {id: demande.id }});
  }

  isSelected(demande : Demande): boolean{
    return this.selectedDemandes.indexOf(demande) >= 0;
  }

  select(demande: Demande, completed: boolean){
    if(completed){
      this.selectedDemandes.push(demande);
    }else{
      const index = this.selectedDemandes.indexOf(demande);
      this.selectedDemandes.splice(index, 1);
    }

    this.selected.emit(this.selectedDemandes);
  }

  setAll(completed: boolean) {
    if(completed){
      this.selectedDemandes = Array.from(this.demandes);
    }else{
      this.selectedDemandes = [];
    }

    this.selected.emit(this.selectedDemandes);
  }

  isAllSelected(){
    return this.selectedDemandes.length === this.demandes.length && this.selectedDemandes.length > 0;
  }

  showDocument(docId){
    this.showViewer = true;
    this.documentToShowId = docId;

  }

  


}
