import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DemandeResponseListComponent } from './demande-response-list.component';

describe('DemandeResponseListComponent', () => {
  let component: DemandeResponseListComponent;
  let fixture: ComponentFixture<DemandeResponseListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DemandeResponseListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DemandeResponseListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
