/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { NotificationService } from '@alfresco/adf-core';
import { stripGeneratedFileSuffix } from '@angular/compiler/src/aot/util';
import { Component, Input, OnInit, Output, SimpleChanges, EventEmitter, ViewChild, Injectable } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { DemandeResponse } from 'app/model/demande';
import { DemandeService } from 'app/services/demande.service';

@Injectable({
  providedIn: 'root'
})
export class MatPaginatorIntlFR extends MatPaginatorIntl {

  itemsPerPageLabel = 'Documents par page';
  nextPageLabel = 'Page Prochaine';
  previousPageLabel = 'Page Précedente';

}

@Component({
  selector: 'app-demande-response-list',
  templateUrl: './demande-response-list.component.html',
  styleUrls: ['./demande-response-list.component.css'],
  providers: [{ provide: MatPaginatorIntl, useClass: MatPaginatorIntlFR }]
})
export class DemandeResponseListComponent implements OnInit {

  @Input()
  responses: DemandeResponse[];

  @Input()
  isPaginator = true;

  @Input()
  name: string;

  @Output()
  showDocument = new EventEmitter<string>();

  editCommentResponse: DemandeResponse;

  displayedColumns: string[] = ['id', 'date', 'support', 'name', 'comment'];

  dataSource = new MatTableDataSource<DemandeResponse>();

  @ViewChild(MatPaginator) paginator: MatPaginator;

  resultsLength = 0;

  constructor(
    private readonly demandeService: DemandeService,
    private readonly notificationService: NotificationService,
  ) { }

  ngOnInit(): void {

  }

  ngOnChanges(changes: SimpleChanges): void {
    this.ngAfterViewInit();
  }

  ngAfterViewInit(): void {

    if (this.responses) {
      this.dataSource = new MatTableDataSource<DemandeResponse>(this.responses);
    }

    if (this.paginator && this.isPaginator) {
      this.dataSource.paginator = this.paginator;
    }
  }

  saveComment(response: DemandeResponse, event: any) {

    this.editCommentResponse = null;
    const comment = event.target.value
    if (this.isCommentChanged(response.comment, comment)) {
      this.demandeService.saveComment(response, comment).subscribe(
        rep => {
          if (rep.statut === 'OK') {
            response.comment = comment;
            this.notificationService
              .showInfo(`Le commentaire pour la réponse id=${response.id} est sauvegardé`);
          } else {
            this.notificationService.showError(rep.message);
          }
        },
        err => {
          this.notificationService
            .showError(`Problème technique en serveur. Le commentaire ne peut pas être sauvegardé. Merci de contacter l'administrateur de l'application.`);
          throw err;
        }
      );
    }
  }

  isCommentChanged(oldComment: string, newComment: string): boolean {
    //if new one and old one are both empty or null or undefined
    if (!oldComment && !newComment) {
      return false;
    }
    //if not equal
    return  oldComment !== newComment;
  }

  editComment(response: DemandeResponse) {
    this.editCommentResponse = response;
  }

  isEditComment(response: DemandeResponse) {
    return this.editCommentResponse === response;

  }

  showResponse(response: DemandeResponse) {
    this.showDocument.emit(response.nodeId);
  }
}
