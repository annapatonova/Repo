/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';

import { merge } from 'rxjs';

import { Contact, ContactInt, Entity, EntityInt } from 'app/model/adress-book';
import { AddressBookService } from 'app/services/address-book.service';
import { DemandeService } from 'app/services/demande.service';
import { ListValidator } from 'app/validators/list-validator';
import { RegexValidator } from 'app/validators/regex-validator';
import { DemandeInt } from 'app/model/demande';

interface SupporOrType {
  libelle: string;
}

interface ResponseData {
  demandes?: DemandeInt[];
  themes?: SupporOrType[];
  supports?: SupporOrType[];
  entites?: EntityInt[];
  contacts: ContactInt[];
}

@Component({
  selector: 'app-demande-form',
  templateUrl: './demande-form.component.html',
  styleUrls: ['./demande-form.component.css']
})
export class DemandeFormComponent implements OnInit {

  @Input()
  fg: FormGroup;

  @Input()
  dossierRef: string;

  @Input()
  direction: 'DEN' | 'DC';

  @Input()
  mode: 'edit' | 'create' = 'create';

  @Output()
  ready = new EventEmitter<void>();

  @Output()
  serverError = new EventEmitter<void>();

  listContact: Contact[];
  listEntity: Entity[];
  delayList = [
    { weeks: null, label: '' },
    { weeks: 1, label: '1 semaine' },
    { weeks: 2, label: '2 semaines' },
    { weeks: 3, label: '3 semaine' },
    { weeks: 4, label: '4 semaines' }
  ];
  supportList = [null];
  typeList: string[];
  anotherDemandesList: string[];


  constructor(
    private readonly adressBookService: AddressBookService,
    private readonly demandeService: DemandeService
  ) { }

  ngOnInit(): void {

    this.initValidators();

    merge(
      this.demandeService.getDemandeList(this.dossierRef),
      this.demandeService.getTypeList(),
      this.demandeService.getSupportList(),
      this.adressBookService.getEtitiesActives(this.direction),
      this.adressBookService.getContactsActives(this.direction)
    ).subscribe(
      rep => {
        this.onSuccess(rep);
      },
      err => {
        this.handleError();
      }

    );
  }

  initValidators() {
    // Alfresco cm:name Regex
    this.fg.controls.demandeLabel.setValidators([Validators.maxLength(256), RegexValidator.alfNamePattern()]);

    // 256 caracters limit
    ['demandeDescription', 'demandeExpectedDocuments'].forEach(ctlName => {
      this.fg.get(ctlName).setValidators([Validators.maxLength(256)]);
    });
  }

  onSuccess(rep: any) {

    if (rep.statut === 'OK' && rep.data) {

      this.initLists(rep.data);

      if (this.isFormReady()) {
        this.ready.emit();
      }

    } else {
      this.handleError();
    }
  }

  initLists(data: ResponseData) {

    if (data.demandes) {
      this.initDemandes(data.demandes);
    }

    else if (data.themes) {
      this.initTypeList(data.themes);
    }

    else if (data.supports) {
      this.initSuppotsList(data.supports);
    }

    else if (data.entites) {
      this.initEntityList(data.entites);
    }

    else if (data.contacts) {
      this.initContactList(data.contacts);
    }
  }

  initDemandes(demandes: DemandeInt[]) {
    this.anotherDemandesList = demandes.map(demande => demande.refDemande);
    this.anotherDemandesList = this.anotherDemandesList.filter(demandeRef => demandeRef !== this.fg.get('demandeNumber').value);
  }

  initTypeList(themes: SupporOrType[]) {
    this.typeList = themes.map(objet => objet.libelle);
  }

  initSuppotsList(supports: SupporOrType[]) {
    this.supportList = [...this.supportList, ...supports.map(objet => objet.libelle)];
  }

  initEntityList(entites: EntityInt[]) {
    this.listEntity = entites.map(entity => new Entity(entity));
    this.fg.controls.demandeEntity.setValidators([ListValidator.inListValidator(this.listEntity)]);
  }

  initContactList(contacts: ContactInt[]) {
    this.listContact = contacts.map(contact => new Contact(contact));
  }

  isFormReady(): boolean {
    return this.anotherDemandesList && this.typeList && this.supportList && this.listEntity && this.listContact ? true : false;
  }

  //TODO MAke global fonction
  getMessage(formControlName: string): string | undefined {
    const errors = this.fg.get(formControlName).errors;

    if (errors?.required) {
      return 'Ce champ est obligatoire';
    }

    if (errors?.alfNamePattern) {
      return `Ce champ ne peut pas se terminer par un point ou un espace. 
              Ce champ ne peut pas contenir les caractères suivants : "*/><?:`;
    }
  }

  handleError() {
    this.ready.emit();
    this.serverError.emit();
  }

}
