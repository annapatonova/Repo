/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { NotificationService } from '@alfresco/adf-core';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Entity } from 'app/model/adress-book';
import { DateFR } from 'app/model/dates';
import { Demande } from 'app/model/demande';
import { UserPermissions } from 'app/model/permissions';
import { DemandeService } from 'app/services/demande.service';
import { UserService } from 'app/services/user.service';
import { of } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';
import { DemandeDialogComponent } from './demande-dialog/demande-dialog.component';

@Component({
  selector: 'app-demande',
  templateUrl: './demande.component.html',
  styleUrls: ['./demande.component.css']
})
export class DemandeComponent implements OnInit {


  currentDemandeRef: string;

  demande: Demande;

  direction: 'DEN' | 'DC';

  documentToShowId: string;

  showViewer = false;

  isLoadingResults = true;

  isServerError = false;

  permissions: UserPermissions = new UserPermissions(null);

  contactRowSpan = 1;

  properties: {
    label: string,
    value: string | number | Entity | DateFR
  }[];

  sendProps: {
    label: string,
    value: string | DateFR | number
  }[];

  constructor(
    public dialog: MatDialog,
    private readonly userService: UserService,
    private readonly router: Router,
    private readonly demandeService: DemandeService,
    private readonly notificationService: NotificationService,
    private readonly activatedRoute: ActivatedRoute) {

    this.activatedRoute.paramMap
      .subscribe(
        paramMap => {
          const demandeRef = paramMap.get('demandeRef');

          if (this.router.getCurrentNavigation()?.extras?.state?.id) {
            this.currentDemandeRef = this.router.getCurrentNavigation()?.extras?.state?.id?.toString();
          } else {
            this.currentDemandeRef = demandeRef;
          }
        },
        err => {
          this.handleError();
        }
      );

    this.userService.getUserPermission().subscribe(
      rep => {
        this.isLoadingResults = false;
        if (rep.statut === 'OK' && rep.data) {
          this.permissions = new UserPermissions(rep.data);
        } else {
          this.permissions = null;
        }
      },
      err => {
        this.isLoadingResults = false;
        this.isServerError = true;
      }
    );
  }

  ngOnInit(): void {

    if (this.permissions) {

      this.demandeService.getDemande(this.currentDemandeRef).subscribe(
        rep => {
          if (rep.statut === 'OK' && rep.data) {
            this.demande = new Demande(rep.data.props);
            this.demande.permissions = rep.data.permissions;
            this.demande.direction = rep.data.direction;
            this.isLoadingResults = false;
            this.properties = this.getPropsToDisplay();
            this.sendProps = this.getSendPropsToDisplay();
            //TODO in get contactRowSpan
            if (this.demande.displayContacts().length > 110) {
              this.contactRowSpan = 2;
            } else {
              this.contactRowSpan = 1;
            }
          } else {
            this.handleError();
          }
        },
        err => {
          this.handleError();
        }
      );

    }


  }

  showDocument(docId) {
    this.showViewer = true;
    this.documentToShowId = docId;

  }

  getPropsToDisplay() {
    return [
      {
        label: 'SIDEC.DEMANDE.NUMBER',
        value: this.demande.number
      },
      {
        label: 'SIDEC.DEMANDE.LABEL',
        value: this.demande.label
      },
      /* {
        label: 'SIDEC.DEMANDE.RECIPIENTS',
        value: this.demande.displayContacts()
      }, */
      {
        label: 'SIDEC.DEMANDE.ENTITY',
        value: this.demande.entity
      },
      {
        label: 'SIDEC.DEMANDE.SUPPORT',
        value: this.demande.support
      },
      {
        label: 'SIDEC.DEMANDE.TYPE',
        value: this.demande.displayTypes()
      }
    ];
  }

  getSendPropsToDisplay() {
    return [
      {
        label: 'SIDEC.DEMANDE.DATE_SENT',
        value: this.demande.sentDate
      },
      {
        label: 'SIDEC.DEMANDE.EXPECTED_RESPONSE_DATE',
        value: this.demande.expectedResponseDate
      },
      {
        label: 'SIDEC.DEMANDE.AUTOMATIC_RESTART_DELAY',
        value: this.demande.getAutoRestartDelay()
      },
      {
        label: 'SIDEC.DEMANDE.STATUS',
        value: this.demande.status
      }
    ];
  }

  handleError() {
    this.isLoadingResults = false;
    this.isServerError = true;
  }

  openDashboard() {
    this.router.navigate(['/dossier', this.demande.parentRef, 0]);
  }

  openDemande(demandeRef: string) {
    this.router.navigate(['/demande'], { queryParams: { ref: demandeRef } });
  }

  openDossierDialog() {
    const dialogRef = this.dialog.open(DemandeDialogComponent, {
      data: { demande: this.demande, mode: 'edit', dossierRef: this.demande.parentRef }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
      if (result && result.message) {
        this.notificationService
          .showInfo(result.message);
      }

    });

  }

}
