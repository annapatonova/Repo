import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DemandeDialogComponent } from './demande-dialog.component';

describe('DemandeDialogComponent', () => {
  let component: DemandeDialogComponent;
  let fixture: ComponentFixture<DemandeDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DemandeDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DemandeDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
