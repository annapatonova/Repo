/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, OnInit, Inject, Input, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NotificationService } from '@alfresco/adf-core';

import { Entity } from 'app/model/adress-book';
import { Demande } from 'app/model/demande';
import { DemandeService } from 'app/services/demande.service';
import { FileUploadComponent } from 'app/widgets/file-upload/file-upload.component';

@Component({
  selector: 'app-demande-dialog',
  templateUrl: './demande-dialog.component.html',
  styleUrls: ['./demande-dialog.component.css']
})
export class DemandeDialogComponent implements OnInit {

  @Input()
  demande: Demande = new Demande(
    {
      refDemande: '',
      name: '',
      entiteDemande: new Entity({
        nom: '',
        code_postal: '',
        ville: '',
        adresse_postale: '',
        telephone: '',
        commentaire: '',
        statut: 'Actif',
        contacts: [],
        pays: ''
      }),
      contactsDemande: [],
      supportDemande: null,
      themesDemande: [],
      dateReponseAttendu: '',
      delaiRelanceAuto: null,
      descriptionDemande: '',
      listeDocsAttendus: '',
      demandesLiees: [],
      piecesJointesDemande: [],
      statutDemande: ''
    }
  );

  profileForm: FormGroup;

  isServerError = false;

  isLoadingResults = true;

  mode: 'create' | 'edit' = 'create';

  dialogTitle: string;

  @ViewChild(FileUploadComponent) uploader: FileUploadComponent;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { mode: 'create' | 'edit', demande?: Demande, dossierRef: string, direction: 'DEN'| 'DC' },
    private readonly formBuilder: FormBuilder,
    private readonly notificationService: NotificationService,
    private readonly dialogRef: MatDialogRef<DemandeDialogComponent>,
    private readonly demandeService: DemandeService
  ) { }

  ngOnInit(): void {

    if (this.data && this.data.demande) {
      this.demande = this.data.demande;
    }

    if(this.data.direction){
      this.demande.direction = this.data.direction
    }

    if (this.data && this.data.mode) {
      this.mode = this.data.mode;
      switch (this.mode) {
        case 'create': {
          this.dialogTitle = 'Nouvelle demande';
          break;
        }
        case 'edit': {
          this.dialogTitle = `Demande ${this.demande.number}`;
          break;
        }
      }
    }

    this.profileForm = this.formBuilder.group({
      demandeNumber: new FormControl(this.demande.number),
      demandeLabel: new FormControl(this.demande.label),
      demandeContacts: new FormControl(this.demande.contacts),
      demandeEntity: new FormControl(this.demande.entity),
      expectedResponseDate: new FormControl(this.demande.expectedResponseDate),
      automaticRestartDelay: new FormControl(this.demande.automaticRestartDelay),
      support: new FormControl(this.demande.support),
      demandeType: new FormControl(this.demande.type),
      demandeDescription: new FormControl(this.demande.description),
      demandeExpectedDocuments: new FormControl(this.demande.expectedDocuments),
      anotherDemandes: new FormControl(this.demande.anotherDemandes)
    });

  }

  onSaveDemande() {

    if (this.profileForm.valid) {
      this.isLoadingResults = true;
      const data = this.profileForm.value;
      data.dossierRef = this.data.dossierRef;
      switch (this.mode) {
        case 'create': {
          this.demandeService.createDemande(this.profileForm.value, this.uploader.getFiles()).subscribe(
            rep => { this.succeed(rep); },
            err => { this.handleError(); }
          );
          break;
        }
        case 'edit': {
          this.demandeService.updateDemande(this.profileForm.value).subscribe(
            rep => { this.succeed(rep); },
            err => { this.handleError(); }
          );
          break;
        }
      }

    }
  }

  succeed(rep: any) {
    if (rep.statut === 'OK') {
      this.dialogRef.close(rep);
    } else {
      this.isLoadingResults = false;
      this.notificationService
        .showError(`Une erreur se produise lors de la sauvegarde de la demande : ${rep.message}`);
    }
  }

  handleError() {
    this.isLoadingResults = false;
    this.notificationService
      .showError("Problème technique en serveur. Merci de contacter l'administrateur de l'application.");
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  formIsReady() {
    this.isLoadingResults = false;
  }

  serverError() {
    this.isLoadingResults = false;
    this.isServerError = true;
  }
}
