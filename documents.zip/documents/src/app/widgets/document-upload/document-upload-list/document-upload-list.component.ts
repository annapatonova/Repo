/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Input, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

import { UploadFile } from 'app/model/commons';

@Component({
  selector: 'app-document-upload-list',
  templateUrl: './document-upload-list.component.html',
  styleUrls: ['./document-upload-list.component.css']
})
export class DocumentUploadListComponent implements OnInit {

  @Input()
  uploadFiles: UploadFile[] = [];

  displayedColumns = ['name', 'message', 'status'];

  dataSource = new MatTableDataSource<UploadFile>();

  constructor() { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {

    this.dataSource = new MatTableDataSource<UploadFile>(this.uploadFiles);


  }

}
