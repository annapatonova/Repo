/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { NotificationService } from '@alfresco/adf-core';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { DocumentUploadDialogComponent } from './document-upload-dialog/document-upload-dialog.component';

@Component({
  selector: 'app-document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['./document-upload.component.css']
})
export class DocumentUploadComponent implements OnInit {

  @Input()
  staticTitle: string;

  @Input()
  tooltip = 'Ajouter un nouveau document';

  @Input()
  multipleFiles = true;

  @Input()
  acceptedFilesType = '*';

  @Input()
  parentType: 'dossier' | 'demande';

  @Input()
  parentRef: string;

  @Output()
  done = new EventEmitter<void>();


  constructor(
    public dialog: MatDialog,
    private readonly notificationService: NotificationService
  ) { }

  ngOnInit(): void {
  }

  onFilesAdded($event: any): void {

    const files = Array.from($event.currentTarget.files);

    if (files.length > 0) {
      this.openDossierDialog(files as File[]);
    }
  }

  openDossierDialog(files: File[]): void {
    const dialogRef = this.dialog.open(DocumentUploadDialogComponent, {
      data: { files, parentRef: this.parentRef, parentType: this.parentType }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.done.emit();
      if (result && result.message) {
        this.notificationService
          .showInfo(result.message);
      }
    });
  }

}
