/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { UploadFile } from 'app/model/commons';
import { UploadService } from 'app/services/upload.service';


@Component({
  selector: 'app-document-upload-dialog',
  templateUrl: './document-upload-dialog.component.html',
  styleUrls: ['./document-upload-dialog.component.css']
})
export class DocumentUploadDialogComponent implements OnInit {

  uploadFiles: UploadFile[] = [];

  done = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { files: File[], parentRef: string, parentType: 'dossier' | 'demande' },
    public readonly dialogRef: MatDialogRef<DocumentUploadDialogComponent>,
    private readonly uploadService: UploadService
  ) { }


  ngOnInit(): void {


    this.data.files.forEach(file =>{

      const uploadFile = new UploadFile(file);
      uploadFile.parentType = this.data.parentType;
      uploadFile.parentRef = this.data.parentRef;

      this.uploadFiles.push(uploadFile);
    });

    this.uploadService.addToQueueAndUpload(this.uploadFiles);

    this.uploadService.isDone().subscribe(data => this.done = data);

  }

  onCloseClick(): void {
    this.dialogRef.close();
}

}
