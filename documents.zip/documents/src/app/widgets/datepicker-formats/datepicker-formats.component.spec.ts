import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatepickerFormatsComponent } from './datepicker-formats.component';

describe('DatepickerFormatsComponent', () => {
  let component: DatepickerFormatsComponent;
  let fixture: ComponentFixture<DatepickerFormatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatepickerFormatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatepickerFormatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
