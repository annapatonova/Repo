/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, ElementRef, ViewChild, Input, OnInit, OnChanges, SecurityContext } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material/autocomplete';
import { MatChipInputEvent, MatChipList } from '@angular/material/chips';

import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { User } from 'app/model/users';
import { DomSanitizer } from '@angular/platform-browser';



@Component({
  selector: 'app-chips-autocomplete',
  templateUrl: 'chips-autocomplete.component.html',
  styleUrls: ['chips-autocomplete.component.css'],
})
export class ChipsAutocompleteComponent implements OnChanges {
  visible = true;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  filteredValues: Observable<string[]>;

  @Input()
  placeholder: string;

  @Input()
  required = false;

  @Input()
  addOnBlur = true;

  @Input()
  chipsValue: any[] = [];

  @Input()
  listValues: any[] = [];

  @Input()
  control: FormControl = new FormControl([]);

  valueCtrl: FormControl = new FormControl('');

  @ViewChild('chipsInput') input: ElementRef<HTMLInputElement>;

  @ViewChild('chipList') chipList: MatChipList;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  constructor(private sanitizer: DomSanitizer) { }

  ngOnChanges(): void {

    if (this.chipsValue === null) this.chipsValue = [];

    this.filteredValues = this.valueCtrl.valueChanges.pipe(
      startWith(null),
      map(value => this.filterOnValueChange(value))
    );

  }

  add(event: MatChipInputEvent): void {

    const sanitizedValue = this.sanitizer.sanitize(SecurityContext.HTML, event.value);

    const value = (sanitizedValue || '').trim();

    if (value === '') return;

    const index = this.listValues.map(object => object.toString()).indexOf(value);

    if (index !== -1 && this.chipsValue.map(chip => chip.toString()).indexOf(value) === -1) {
      this.chipsValue.push(this.listValues[index]);
      this.control.setValue(this.chipsValue);
    }

    const input = event.input;

    if (input) {
      input.value = '';
    }

    this.valueCtrl.setValue(null);

  }

  remove(value: any): void {
    const index = this.chipsValue.indexOf(value);

    if (index >= 0) {
      this.chipsValue.splice(index, 1);
    }
    this.control.setValue(this.chipsValue);
    this.valueCtrl.setValue(null);
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    const value = event.option.value;
    this.selectValue(value);
  }

  selectValue(value: string) {
    const index = this.listValues.map(el => el.toString()).indexOf(value);
    if (index !== -1) {
      const valueObj = this.listValues[index];

      if (this.chipsValue.indexOf(valueObj) === -1) {
        this.chipsValue.push(valueObj);
        this.control.setValue(this.chipsValue);
      }
    }
    this.input.nativeElement.value = '';

    this.valueCtrl.setValue(null);
    this.valueCtrl.disable();
    this.valueCtrl.enable();
  }

  private filterOnValueChange(value: string | null): string[] {
    let result: string[] = [];

    const allSelectedValues = this.listValues.filter(object => this.chipsValue.map(chip => chip.toString()).indexOf(object.toString()) < 0);

    if (value) {
      result = this.filter(allSelectedValues, value);
    } else {
      result = allSelectedValues.map(el => el.toString());
    }

    return result;
  }

  private filter(list: any[], value: string): string[] {

    let filteredList: any[] = [];

    const filterValue = value.toLowerCase();

    filteredList = list.filter(element => element.toString().toLowerCase().indexOf(filterValue) >= 0);

    return filteredList.map(element => element.toString());
  }


}