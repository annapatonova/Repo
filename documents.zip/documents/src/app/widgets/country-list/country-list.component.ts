/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';

import { AddressBookService } from 'app/services/address-book.service';
import { CountryValidator } from 'app/validators/country-validator';

@Component({
    selector: 'app-country-list',
    templateUrl: './country-list.component.html',
    styleUrls: ['./country-list.component.css']
})
export class CountryListComponent implements OnInit {

    @Input()
    pageSize = 10;

    @Input()
    required = false;

    @Input()
    errorMessage = 'Aucun pays ne correspond à la recherche';

    @Input()
    countryCtrl: FormControl;

    @Output()
    isReady = new EventEmitter<void>();

    @Output()
    isServerError = new EventEmitter<void>();

    isEnd: boolean;

    batchNum = 2;

    listCountry: any[];

    constructor(
        private readonly adressBookService: AddressBookService
    ) { }

    ngOnInit(): void {
        
        this.countryCtrl.setAsyncValidators([CountryValidator.inListValidator(this.adressBookService)]);

        this.initCountryList(true);

        this.countryCtrl.valueChanges.subscribe(
            keyword => {
                this.initCountryList(false, keyword);
            },
            err => {
                this.handleError();
            }
        );
    }

    initCountryList(firstCall: boolean, keyword?: string){

        this.adressBookService.getCountriesList(this.pageSize, 1, keyword).subscribe(
            rep => {
                this.listCountry = rep.data.pays.map(p => p.libelleFR);

                if (this.listCountry.length >= this.pageSize) {
                    this.batchNum = 2;
                    this.isEnd = false;
                } else {
                    this.isEnd = true;
                }
                if(firstCall) {
                    this.isReady.emit();
                }
            },
            err => {
                this.handleError();
            }
        );

    }

    getNextBatch() {
        if (!this.isEnd) {
            this.adressBookService.getCountriesList(this.pageSize, this.batchNum, this.countryCtrl.value).subscribe(
                rep => {
                    this.listCountry = [...this.listCountry, ...rep.data.pays.map(p => p.libelleFR)];
                    if (this.listCountry.length >= this.pageSize) {
                        this.batchNum++;
                    } else {
                        this.isEnd = true;
                    }
                },
                err => {
                    this.handleError();
                }
            );

        }

    }

    handleError(){
        this.isServerError.emit();
    }

}
