/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, OnInit, Input, Output, EventEmitter, SecurityContext } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
      selector: 'app-file-upload',
      templateUrl: './file-upload.component.html',
      styleUrls: ['./file-upload.component.css'],
      animations: [
            trigger('fadeInOut', [
                  state('in', style({ opacity: 100 })),
                  transition('* => void', [
                        animate(300, style({ opacity: 0 }))
                  ])
            ])
      ]
})
export class FileUploadComponent implements OnInit {

      @Input() text = 'Importer un document';

      @Input() param = 'file';

      @Input() accept = '*';

      @Input() removable = true;

      @Output() complete = new EventEmitter<string>();

      files: Array<File> = [];

      constructor(private sanitizer: DomSanitizer) {
            this.text = this.sanitizer.sanitize(SecurityContext.HTML, this.text);
       }

      ngOnInit() {}

      onFilesAdded($event: any): void {

            let files: File[] = Array.from($event.currentTarget.files);

            files = files.filter(file => this.files.map(f => f.name).indexOf(file.name) === -1);
        
            if (files.length > 0) {
                  this.files = [...this.files, ...files];
            }

            const fileUpload = document.getElementById('fileUpload') as HTMLInputElement;

            fileUpload.value = ''; 
 
      }

      sinitizedFilename(file: File){
            return this.sanitizer.sanitize(SecurityContext.HTML, file.name);
      }

      cancelFile(file: File) {

            const index = this.files.indexOf(file);
            if (index > -1) {
                  this.files.splice(index, 1);
            }
      }

      getFiles(): File[] {
            return this.files;
      }

}
