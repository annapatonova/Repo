/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import {Component, ViewChild, Input, Output, EventEmitter, OnChanges, SimpleChanges} from '@angular/core';
import {FormControl} from '@angular/forms';
import { MatAutocomplete, MatAutocompleteTrigger } from '@angular/material/autocomplete';

import {Observable, fromEvent} from 'rxjs';
import {map, takeUntil} from 'rxjs/operators';


@Component({
  selector: 'app-autocomplete-overview',
  templateUrl: './autocomplete-overview.component.html',
  styleUrls: ['./autocomplete-overview.component.css']
})
export class AutocompleteOverviewComponent implements OnChanges {
  
  @Input()
  valueCtrl = new FormControl();
 
  @Input()
  placeholder: string;

  @Input()
  filteredValues$: Observable<any>;
  
  @Input()
  pageSize = 10;

  @Input()
  required: boolean;

  @Input()
  list: string[];

  @Input()
  label: string;

  @Input()
  errorMessage: string;

  @Input()
  inList: boolean;

  @Output() endScroll = new EventEmitter<void>();

  @ViewChild('valueAutocomplete') autocompleteRef: MatAutocomplete;
  
  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger: MatAutocompleteTrigger;

  constructor() {}
  
  ngOnChanges(changes: SimpleChanges): void {
   
  }

  ngOnInit(): void {
   
  }


  autocompleteScroll() {
    setTimeout(() => {
      if (
        this.autocompleteRef &&
        this.autocompleteTrigger &&
        this.autocompleteRef.panel
      ) {
        fromEvent(this.autocompleteRef.panel.nativeElement, 'scroll')
          .pipe(
            map(x => this.autocompleteRef.panel.nativeElement.scrollTop),
            takeUntil(this.autocompleteTrigger.panelClosingActions)
          )
          .subscribe(x => {
            const scrollTop = this.autocompleteRef.panel.nativeElement
              .scrollTop;
            const scrollHeight = this.autocompleteRef.panel.nativeElement
              .scrollHeight;
            const elementHeight = this.autocompleteRef.panel.nativeElement
              .clientHeight;
              const atBottom = scrollHeight === scrollTop + elementHeight;
            if (atBottom) {
              // fetch more data
              this.endScroll.emit();
            }
          });
      }
    });
  }
}
