/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Component, Input, ViewChild, EventEmitter, Output, OnChanges } from '@angular/core';
import { FormControl} from '@angular/forms';
import { MatAutocomplete, MatAutocompleteTrigger } from '@angular/material/autocomplete';

import { Observable } from 'rxjs';
import { map, startWith, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-filtered-autocomplete',
  templateUrl: './filtered-autocomplete.component.html',
  styleUrls: ['./filtered-autocomplete.component.css']
})
export class FilteredAutocompleteComponent implements OnChanges {

  @Input()
  formCtrl: FormControl;

  @Input()
  label: string;

  @Input()
  required = false;

  @Input()
  errorMessage: string;

  @Input()
  maxlengthMesage: string;

  @Input()
  list: any[];

  filteredValue: Observable<any[]>;

  @ViewChild('auto') autocompleteRef: MatAutocomplete;
  
  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger: MatAutocompleteTrigger;

  constructor() { }

  ngOnInit(): void {

    this.filteredValue = this.getFiltered(this.formCtrl, this.list);

  }

  ngOnChanges(){

    this.filteredValue = this.getFiltered(this.formCtrl, this.list);
  }

  getFiltered(control: FormControl, list: any[]): Observable<any[]> {
    if (list) {
      return control.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value, list))
        );
    }
    return null;
  }

  private _filter(value: string, options: any[]): any[] {

    const filterValue = value.toString().toLowerCase();

    return options.filter(option => option.toString().toLowerCase().includes(filterValue));

  }


}
