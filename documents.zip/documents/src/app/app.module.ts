/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatSelectInfiniteScrollModule} from 'ng-mat-select-infinite-scroll';

import { CoreModule, TRANSLATION_PROVIDER, TranslateLoaderService } from '@alfresco/adf-core';
import { ContentModule } from '@alfresco/adf-content-services';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { DragDropModule } from '@angular/cdk/drag-drop';


import { appRoutes } from './app.routes';

// App components
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AppLayoutComponent } from './components/app-layout/app-layout.component';

import { DocumentListComponent } from './components/document/document-list/document-list.component';

import { CreateDossierComponent } from './components/dossier/create-dossier/create-dossier.component';
import { DossierDialogComponent } from './components/dossier/dossier-dialog/dossier-dialog.component';
import { DossierListComponent } from './components/dossier/dossier-list/dossier-list.component';
import { DossierWorkspaceComponent } from './components/dossier/dossier-workspace/dossier-workspace.component';
import { DossierFormComponent } from './components/dossier/dossier-form/dossier-form.component';
import { DossierDashboardComponent } from './components/dossier/dossier-dashboard/dossier-dashboard.component';

import { AddressBookComponent } from './components/address-book/address-book.component';

import { EntityFormComponent } from './components/address-book/entity/entity-form/entity-form.component';
import { EntityDialogComponent } from './components/address-book/entity/entity-dialog/entity-dialog.component';
import { EntityListComponent } from './components/address-book/entity/entity-list/entity-list.component';
import { EntityComponent } from './components/address-book/entity/entity.component';

import { ContactDialogComponent } from './components/address-book/contact/contact-dialog/contact-dialog.component';
import { ContactFormComponent } from './components/address-book/contact/contact-form/contact-form.component';
import { ContactListComponent } from './components/address-book/contact/contact-list/contact-list.component';
import { ContactComponent } from './components/address-book/contact/contact.component';

import { DemandeComponent } from './components/demande/demande.component';
import { DemandeFormComponent } from './components/demande/demande-form/demande-form.component';
import { DemandeDialogComponent } from './components/demande/demande-dialog/demande-dialog.component';
import { DemandeListComponent } from './components/demande/demande-list/demande-list.component';
import { DemandeResponseListComponent } from './components/demande/demande-response-list/demande-response-list.component';

import { DocumentUploadComponent } from './widgets/document-upload/document-upload.component';
import { DocumentUploadDialogComponent } from './widgets/document-upload/document-upload-dialog/document-upload-dialog.component';
import { DocumentUploadListComponent } from './widgets/document-upload/document-upload-list/document-upload-list.component';

import { DatepickerFormatsComponent } from './widgets/datepicker-formats/datepicker-formats.component';
import { ChipsAutocompleteComponent } from './widgets/chips-autocomplete/chips-autocomplete.component';
import { AutocompleteOverviewComponent } from './widgets/autocomplete-overview/autocomplete-overview.component';
import { FilteredAutocompleteComponent } from './widgets/filtered-autocomplete/filtered-autocomplete.component';
import { CountryListComponent } from './widgets/country-list/country-list.component';
import { FileUploadComponent } from './widgets/file-upload/file-upload.component';

// Localization
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { DossierComponent } from './components/dossier/dossier.component';
import { SentDemandesStatusComponent } from './components/dossier/dossier-dashboard/sent-demandes-status/sent-demandes-status.component';

registerLocaleData(localeFr);

@NgModule({
    imports: [
        DragDropModule,
        BrowserModule,
        BrowserAnimationsModule,
        MatGridListModule,
        MatPaginatorModule,
        MatSelectInfiniteScrollModule,
        RouterModule.forRoot(appRoutes, { useHash: true,
            enableTracing: false, // enable for debug only
            initialNavigation: true }),
        // ADF modules
        CoreModule.forRoot(),
        ContentModule.forRoot(),
        TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: TranslateLoaderService }
        })
    ],
    declarations: [
        AppComponent,
        HomeComponent,
        LoginComponent,
        AppLayoutComponent,
        FileUploadComponent,
        DatepickerFormatsComponent,
        ChipsAutocompleteComponent,
        AutocompleteOverviewComponent,
        FilteredAutocompleteComponent,
        CountryListComponent,
        FileUploadComponent,
        CreateDossierComponent,
        DossierListComponent,
        DossierWorkspaceComponent,
        DossierFormComponent,
        DossierDashboardComponent,
        DossierDialogComponent,
        AddressBookComponent,
        DocumentListComponent,
        EntityListComponent,
        EntityComponent,
        EntityFormComponent,
        EntityDialogComponent,
        ContactDialogComponent,
        ContactListComponent,
        ContactComponent,
        ContactFormComponent,
        DemandeComponent,
        DemandeFormComponent,
        DemandeDialogComponent,
        DemandeListComponent,
        DemandeResponseListComponent,
        DocumentUploadComponent,
        DocumentUploadDialogComponent,
        DocumentUploadListComponent,
        DossierComponent,
        SentDemandesStatusComponent
    ],
    providers: [
        {
            provide: TRANSLATION_PROVIDER,
            multi: true,
            useValue: {
                name: 'app',
                source: 'resources'
            }
        }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
