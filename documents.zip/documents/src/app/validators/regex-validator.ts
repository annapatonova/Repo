/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class RegexValidator {


    static excludePattern(regex: RegExp): ValidatorFn {
        return (control: AbstractControl): ValidationErrors | null => {
            const isMatch = control.value.match(regex);
            return isMatch ? { excludePattern: true } : null;
        };
    }

    static alfNamePattern(): ValidatorFn {
        return (control: AbstractControl): ValidationErrors | null => {
            const regex = /(.*[\"\*\\\>\<\?\/\:\|]+.*)|(.*[\.]?.*[\.]+$)|(.*[ ]+$)/g;
            const isMatch = control.value.match(regex);
            return isMatch ? { alfNamePattern: true } : null;
        };
    }
}