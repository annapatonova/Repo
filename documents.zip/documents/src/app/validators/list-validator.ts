/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class ListValidator {


    static inListValidator(list: any[]): ValidatorFn {
        return (control: AbstractControl): ValidationErrors | null => {
            if (!control.value || control.value === '') { 
                return null; 
            }
            const inList = (list.indexOf(control.value) > -1);
            return inList ? null : { notInList: true };
        };
    }
}