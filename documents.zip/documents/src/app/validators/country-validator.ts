/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import {AbstractControl, AsyncValidatorFn, ValidationErrors} from '@angular/forms';
import {Observable, of} from 'rxjs';
import {map} from 'rxjs/operators';

import { AddressBookService } from 'app/services/address-book.service';

export class CountryValidator {


  static  inListValidator(adressBookService: AddressBookService): AsyncValidatorFn {
        return (control: AbstractControl): Observable<ValidationErrors> => {
            if (!control.value || control.value === '') { 
                return of(null); 
            }
            return adressBookService.getCountriesList(null, null, control.value).pipe(
                map(
                    (rep) => {
                        const countries: string[] = rep.data.pays.map(p => p.libelleFR);
                        if (countries.indexOf(control.value) > -1) {
                            return null;
                        } else {
                            return { invalidAsync: true };
                        }
    
                    }
                ));
        };
    }
}