/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Contact, ContactInt, Entity, EntityInt } from './adress-book';
import { DocumentInt, Document, Permission } from './commons';
import { DateFR } from './dates';
import { User } from './users';

export interface DemandeResponseInt {

    created: string;
    creator: User;
    modified: string;
    modifier: User;
    id: string;
    name: string;
    identifiantReponseDemande: string;
    horodatageDepotPLANE: string;
    supportReponseDemande: string;
    commentaireReponseDemande: string;
    refDemandeReponse: string;
}

export class DemandeResponse {

    id: string;
    date: DateFR | '';
    nodeId: string;
    name: string;
    comment: string
    support: string;
    refDemande: string

    constructor(response: DemandeResponseInt) { 
        this.id = response.identifiantReponseDemande;
        this.date = DateFR.initDate(response.horodatageDepotPLANE);
        this.nodeId = response.id;
        this.name = response.name;
        this.support = response.supportReponseDemande;
        this.comment = response.commentaireReponseDemande;
        this.refDemande = response.refDemandeReponse;
    }
}

export interface DemandePermissionsInt {
    contactsDemande: Permission[];
    dateReponseAttendue: Permission[];
    delaiRelanceAuto: Permission[];
    demandesLiees: Permission[];
    descriptionDemande: Permission[];
    entiteDemande: Permission[];
    listeDocsAttendus: Permission[];
    name: Permission[];
    piecesJointesDemande: Permission[];
    refDemande: Permission[];
    statutDemande: Permission[];
    supportDemande: Permission[];
    tagsDemande: Permission[];
    themeDemande: Permission[];
}

export interface DemandeInt {
    refDossierParent?: string;
    refDemande: string;
    name: string;
    entiteDemande?: EntityInt;
    contactsDemande: ContactInt[];
    supportDemande: string;
    themesDemande: string[];
    dateReponseAttendu: string;
    datesRelances?: string[];
    delaiRelanceAuto: number;
    descriptionDemande: string;
    listeDocsAttendus: string;
    demandesLiees: string[];
    statutDemande?: string;
    reponsesDemande?: DemandeResponseInt[];
    emailsRelances?: string[];
    dateEnvoi?: string;
    piecesJointesDemande?: DocumentInt[];
    id?:string;

}

export class Demande {
    parentRef: string;
    number: string;
    label: string;
    contacts: Contact[];
    entity: Entity;
    expectedResponseDate: DateFR | '';
    sentDate: DateFR | '';
    automaticRestartDelay: number;
    support: string;
    type: string[];
    description: string;
    expectedDocuments: string;
    anotherDemandes: string[];
    responses: DemandeResponse[];
    status: string;
    id: string;

    attachments: Document[];
    permissions: DemandePermissionsInt;

    direction: 'DEN' | 'DC';


    constructor(demande: DemandeInt) {
        this.parentRef = demande.refDossierParent;
        this.number = demande.refDemande;
        this.label = demande.name;
        this.contacts = (demande.contactsDemande || []).map(contact => new Contact(contact));
        this.entity = new Entity(demande.entiteDemande);
        this.expectedResponseDate = DateFR.initDate(demande.dateReponseAttendu);
        this.sentDate = DateFR.initDate(demande.dateEnvoi);
        this.automaticRestartDelay = demande.delaiRelanceAuto;
        this.support = demande.supportDemande === '' ? null: demande.supportDemande;
        this.type = demande.themesDemande;
        this.description = demande.descriptionDemande;
        this.expectedDocuments = demande.listeDocsAttendus;
        this.anotherDemandes = demande.demandesLiees;
        this.attachments = demande.piecesJointesDemande.map(document => new Document(document));
        this.status = demande.statutDemande;
        this.responses = demande.reponsesDemande?.map(response => new DemandeResponse(response));
        this.id = demande.id;
    }

    canModify(): boolean {
        return this.permissions.name.indexOf(Permission.UPDATE) >= 0 && this.status ==='Sauvegardée';
    }

    getAutoRestartDelay(): string {
        switch (this.automaticRestartDelay) {
            case 0:
                return '';
            case undefined:
                return '';
            case null :
                return '';
            case 1:
                return '1 semaine';
            default:
                return `${this.automaticRestartDelay} semaines`;
        }
    }

    displayContacts(): string {
        return this.contacts ? this.contacts.join(', ') : '';
    }

    displayTypes(): string {
        return this.type ? this.type.join(', ') : '';
    }

    toString() {
        return `${this.number} ${this.label}`;
    }
}

export interface SendDempandeResponseInt{
    data: { 
        name: string,
        refDemande: string
    };
    statut: 'OK' | 'KO';
    message: string;
  }
  
  export class SendDempandeResponse{
    demandeRef: string;
    demandeName: string;
    status: 'OK' | 'KO';
    message: string;
    
    constructor(response: SendDempandeResponseInt){
      this.demandeRef = response.data.refDemande;
      this.demandeName = response.data.name;
      this.status = response.statut;
      this.message = response.message;
    }
  
    isSuccess(){
      return this.status ==='OK';
    }
  
    isError(){
      return this.status === 'KO';
    }
  }