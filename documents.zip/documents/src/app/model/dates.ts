  /*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
  export class DateFR extends Date{

    static initDate(date: string){
      return (!date || date ===(''|| null)) ? '' : new DateFR(date);
    }

    toString(): string {

        const year = this.getFullYear();
        let month = this.getMonth() + 1;
        let dt = this.getDate();
    
        if (dt < 10) {
          dt = 0 + dt;
        }

        if (month < 10) {
          month = 0 + month;
        }

        return `${dt}/${month}/${year}`;
      }

  }