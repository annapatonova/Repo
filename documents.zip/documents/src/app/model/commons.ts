/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Subscription } from 'rxjs';
import { DateFR } from './dates';
import { User } from './users';


export enum UploadFileStatus {
  Pending,
  Success,
  Error,
  Progress
}

export class UploadFile {
  public file: File;
  public progress = 0;
  public status = UploadFileStatus.Pending;
  public errorMessage: string;
  public parentRef: string;
  public parentType: 'dossier' | 'demande';
  public request: Subscription = null;


  // actions
  public upload = () => { /* set in service */ };
  public cancel = () => { /* set in service */ };
  public remove = () => { /* set in service */ };


  constructor(file: File) {
    this.file = file;
  }

  // statuses
  public isPending = () => this.status === UploadFileStatus.Pending;
  public isSuccess = () => this.status === UploadFileStatus.Success;
  public isError = () => this.status === UploadFileStatus.Error;
  public inProgress = () => this.status === UploadFileStatus.Progress;
  public isUploadable = () => this.status === UploadFileStatus.Pending || this.status === UploadFileStatus.Error;

  getMessage(){

    switch(this.status){
      case UploadFileStatus.Success :
        return 'Le document a été importé avec succès';
      case UploadFileStatus.Error :
        return this.errorMessage;
      case UploadFileStatus.Progress :
        return this.getProgressLabel();
      case UploadFileStatus.Pending :
        return 'Le document est en attente ';
      default:
        return '';
    }
  }

  getSizeLabel(fractionDigits: number) {
    const sizeMB = (this.file.size / 10485760).toFixed(fractionDigits);
    return `${sizeMB} MB`;
  }

  getProgressLabel() {
    return `${this.progress} %`;
  }

  getProgressSizeLabel(fractionDigits: number) {

    const sizeLoaded = Math.round((this.file.size / 100) * this.progress);

    const sizeLoadedMB = (sizeLoaded / 10485760).toFixed(fractionDigits);

    return `${sizeLoadedMB}/${this.getSizeLabel(fractionDigits)}`;
  }
}

export enum Permission {
  READ = 'READ',
  ADD = 'ADD',
  DELETE = 'DELETE',
  UPDATE = 'UPDATE'
}

export interface DocumentInt {
  name: string;
  created: string;
  id: string;
  modified: string;
  modifier: User;
  creator: User;
}

export class Document {

  name: string;
  created: DateFR | '';
  id: string;
  modified: DateFR | '';
  modifier: User;
  creator: User;

  constructor(document: DocumentInt) {
    this.name = document.name;
    this.id = document.id;
    this.created = DateFR.initDate(document.created);
    this.modified = DateFR.initDate(document.modified);
    this.modifier = document.modifier;
    this.creator = new User(document.creator);
  }

  toString() {
    return this.name;
  }
}