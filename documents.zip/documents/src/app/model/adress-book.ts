/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */

//TODO: change names + see for optional args and requireds ones
export interface ContactInt {

    adresse_postale: string;
    civilite: string;
    code_postal: string;
    courriel: string;
    entites?: Entity[];
    fonction: string;
    nom: string;
    pays: string;
    prenom: string;
    statut: string;
    telecopie: string;
    telephone: string;
    ville: string;

}

export class Contact{

    adresse_postale: string;
    civilite: string;
    code_postal: string;
    courriel: string;
    entites: Entity[];
    fonction: string;
    nom: string;
    pays: string;
    prenom: string;
    statut: string;
    telecopie: string;
    telephone: string;
    ville: string;

    constructor(contact: ContactInt) {
        this.nom = contact.nom;
        this.prenom = contact.prenom;
        this.civilite = contact.civilite;
        this.courriel = contact.courriel;
        this.fonction = contact.fonction;
        this.code_postal = contact.code_postal;
        this.ville = contact.ville;
        this.adresse_postale = contact.adresse_postale;
        this.telephone = contact.telephone;
        this.telecopie = contact.telecopie;
        this.statut = contact.statut;
        this.entites = contact.entites.map(entity => new Entity(entity));
        this.pays = contact.pays;
    }

    displayListEntities(): string {
        return this.entites.length > 0 ? this.entites.join(', ') : '';
    }

    toString(): string {
        return `${this.nom} ${this.prenom}`;
    }

}

export interface EntityInt {

    nom: string;
    code_postal: string;
    ville: string;
    adresse_postale: string;
    telephone: string;
    commentaire: string;
    statut: string;
    contacts: Contact[];
    pays: string;

}

export class Entity implements EntityInt {
    nom: string;
    code_postal: string;
    ville: string;
    adresse_postale: string;
    telephone: string;
    commentaire: string;
    statut: string;
    contacts: Contact[];
    pays: string;

    constructor(entity: EntityInt) {
        this.nom = entity.nom? entity.nom : '';
        this.code_postal = entity.code_postal;
        this.ville = entity.ville;
        this.adresse_postale = entity.adresse_postale;
        this.telephone = entity.telephone;
        this.commentaire = entity.commentaire;
        this.statut = entity.statut;
        this.contacts = entity.contacts?.map(contact => new Contact(contact));
        this.pays = entity.pays;
    }

    displayListContact(): string{
        return this.contacts.join(', ');
    }

    toString(): string {
        return `${this.nom}`;
    }
}