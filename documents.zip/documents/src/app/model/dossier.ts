/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
import { Document, DocumentInt, Permission } from './commons';
import { DateFR } from './dates';
import { User } from './users';

//TODO english names + see for optional args and requireds ones

export enum StatutDossier {
    OPEN = 'Ouvert (Analyse)',
    TRANSMITTED = 'Transmis au SCCS/DICS',
    CLOSED = 'Clos',
    ARCHIVED = 'Archivé'
}

export interface DossierPermissionsInt {
    refDossier: Permission[];
    name: Permission[];
    dateOuvertureDossier: Permission[];
    dateClotureDossier: Permission[];
    entiteDossier: Permission[];
    contactDossier: Permission[];
    chargeDossier1: Permission[];
    chargeDossier2: Permission[];
    autresIntervenantsInternes: Permission[];
    autresIntervenantsExternes: Permission[];
    collaborateursAMF: Permission[];
    statutDossier: Permission[];
    tagsDossier: Permission[];
    piecesJointesDossier: DocumentInt[];
}

export interface DossierInt {
    refDossier: string;
    name: string;
    dateOuvertureDossier: string;
    dateClotureDossier: string;
    entiteDossier: string;
    contactDossier: string;
    chefDeMission: User;
    autresChargesDeDossier: User[];
    statutDossier: StatutDossier;
    tagsDossier: string[];
    piecesJointesDossier: DocumentInt[];

    permissions: DossierPermissionsInt;

    direction: 'DEN' | 'DC';
}

export class Dossier {

    refDossier: string;
    name: string;
    dateOuvertureDossier: DateFR | '';
    dateClotureDossier: DateFR | '';
    entiteDossier: string;
    contactDossier: string;
    missionHead: User;
    otherDossierCharged: User[];
    statutDossier: StatutDossier;
    tagsDossier: string[];
    piecesJointesDossier: Document[];

    permissions: DossierPermissionsInt;

    direction: 'DEN' | 'DC';

    constructor(dossier: DossierInt) {
        this.refDossier = dossier.refDossier;
        this.name = dossier.name;
        this.dateOuvertureDossier = DateFR.initDate(dossier.dateOuvertureDossier);
        this.dateClotureDossier = DateFR.initDate(dossier.dateClotureDossier);
        this.entiteDossier = dossier.entiteDossier;
        this.contactDossier = dossier.contactDossier;
        this.missionHead = new User(dossier.chefDeMission);
        this.otherDossierCharged = (dossier.autresChargesDeDossier || []).map(user => new User(user));
        this.statutDossier = dossier.statutDossier;
        this.tagsDossier = dossier.tagsDossier;
        this.piecesJointesDossier = (dossier.piecesJointesDossier || []).map(document => new Document(document));

        this.permissions = dossier.permissions;

        this.direction = dossier.direction;
    }

    canModify(): boolean {
        return this.permissions.name.indexOf(Permission.UPDATE) >= 0;
    }

    displayOtherDossierCharged(): string {
        return this.otherDossierCharged.join(', ');
    }

}

