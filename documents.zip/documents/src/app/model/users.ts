/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */

//TODO eng names + see for optional args and requireds ones + implements interface ??

export interface User {
    firstName: string;
    email: string;
    fullName: string;
    lastName: string;
    login: string;
}

export class User implements User {

    constructor(user: User) {
        this.firstName = user.firstName;
        this.email = user.email;
        this.fullName = user.fullName;
        this.lastName = user.lastName;
        this.login = user.login;
    }

    toString(): string {
        return `${this.firstName} ${this.lastName}`;
    }
}