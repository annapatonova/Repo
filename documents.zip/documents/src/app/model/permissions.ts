/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */

//TODO eng names + see for optional args and requireds ones

export interface UserPermissionsInt{
    dossier: ('LIST' | 'CREATE')[];
    annuaire: ('LIST' | 'CREATE')[];
}

export class UserPermissions{
    dossier: ('LIST' | 'CREATE')[];
    annuaire: ('LIST' | 'CREATE')[];

    constructor(perm: UserPermissionsInt){
        this.dossier = perm?.dossier;
        this.annuaire = perm?.annuaire;
    }

    canCreateDossier(): boolean{
        return this.dossier.indexOf('CREATE') >= 0;
    }

    canOpenAdressBook(): boolean{
        return this.annuaire.length > 0;
    }
    canCreateAdressBook(): boolean{
        return this.annuaire.length > 0;
    }
}